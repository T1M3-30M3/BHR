GIF89a;
<?php
phpinfo();
?>