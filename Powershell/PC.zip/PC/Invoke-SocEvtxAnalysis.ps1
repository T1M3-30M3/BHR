<#
.SYNOPSIS
    SOC Windows Event Log (EVTX) & IP Activity Analyzer
    Parses Security / System / PowerShell (and Sysmon, if installed) logs,
    flags common attacker TTPs (brute force, privilege escalation, persistence,
    lateral movement, log tampering, suspicious PowerShell/process activity),
    extracts every IP address it encounters, and writes one .txt report per
    category plus a summary.

.DESCRIPTION
    Works two ways:
      1) LIVE mode  - reads directly from the local event log channels
                       (needs to run elevated / as Administrator).
      2) FILE mode  - point it at a folder of exported .evtx files
                       (e.g. collected from multiple hosts for triage).

.PARAMETER Mode
    'Live' (default) or 'File'

.PARAMETER EvtxFolder
    Folder containing .evtx files. Required when -Mode File.

.PARAMETER OutputPath
    Folder where the .txt reports are written. Created if missing.

.PARAMETER DaysBack
    How many days of history to pull in Live mode. Default 7.

.PARAMETER FailedLogonThreshold
    Number of failed logons from a single source (IP or account) inside the
    window before it's flagged as probable brute force. Default 5.

.EXAMPLE
    # Analyze the local machine's last 7 days, elevated PowerShell
    .\Invoke-SocEvtxAnalysis.ps1 -Mode Live -OutputPath C:\SOC\Report

.EXAMPLE
    # Analyze a folder of collected .evtx exports (no admin needed)
    .\Invoke-SocEvtxAnalysis.ps1 -Mode File -EvtxFolder C:\Collected -OutputPath C:\SOC\Report

.NOTES
    Read-only / detection tool. Does not modify, delete, or clear any logs.
    Run in an elevated PowerShell session for Live mode (Security log requires it).
#>

[CmdletBinding()]
param(
    [ValidateSet('Live','File')]
    [string]$Mode = 'Live',

    [string]$EvtxFolder,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [int]$DaysBack = 7,

    [int]$FailedLogonThreshold = 5
)

$ErrorActionPreference = 'Continue'
$StartTime = Get-Date

if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
}

$TimeStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$OutputPath = Join-Path $OutputPath "SOC_Report_$TimeStamp"
New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null

$IpRegex = '(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d.])'
$AllIpHits = New-Object System.Collections.Generic.List[object]

function Write-Section {
    param([string]$File, [string]$Text)
    Add-Content -Path (Join-Path $OutputPath $File) -Value $Text
}

function Get-EventXmlData {
    <# Pulls the <EventData>/<UserData> Name/Value pairs into a hashtable #>
    param($Event)
    $data = @{}
    try {
        $xml = [xml]$Event.ToXml()
        $nodes = $xml.Event.EventData.Data
        if (-not $nodes) { $nodes = $xml.Event.UserData.FirstChild.ChildNodes }
        foreach ($n in $nodes) {
            if ($n.Name) { $data[$n.Name] = $n.'#text' }
        }
    } catch {}
    return $data
}

function Get-Events {
    param(
        [string]$LogName,
        [int[]]$Id,
        [string]$EvtxPath
    )
    $filter = @{ Id = $Id }
    if ($Mode -eq 'Live') {
        $filter['LogName'] = $LogName
        $filter['StartTime'] = (Get-Date).AddDays(-$DaysBack)
    } else {
        $filter['Path'] = $EvtxPath
    }
    try {
        Get-WinEvent -FilterHashtable $filter -ErrorAction Stop
    } catch {
        # Silently return nothing if channel/ids absent in this source (normal/expected)
        @()
    }
}

function Get-TargetEvtxFiles {
    param([string]$LogNameHint)
    Get-ChildItem -Path $EvtxFolder -Filter *.evtx -File |
        Where-Object { $_.Name -match [regex]::Escape($LogNameHint) -or $LogNameHint -eq '*' }
}

function Invoke-LogQuery {
    <#
        Wrapper that runs Get-Events in Live mode against a named channel,
        or against every matching .evtx file in File mode, and returns the
        combined event objects.
    #>
    param(
        [string]$LogName,
        [int[]]$Id,
        [string]$FileHint = '*'
    )
    $results = New-Object System.Collections.Generic.List[object]
    if ($Mode -eq 'Live') {
        Get-Events -LogName $LogName -Id $Id | ForEach-Object { $results.Add($_) }
    } else {
        if (-not $EvtxFolder -or -not (Test-Path $EvtxFolder)) {
            Write-Warning "EvtxFolder '$EvtxFolder' not found."
            return $results
        }
        $files = Get-TargetEvtxFiles -LogNameHint $FileHint
        foreach ($f in $files) {
            Get-Events -EvtxPath $f.FullName -Id $Id | ForEach-Object { $results.Add($_) }
        }
    }
    return $results
}

function Record-Ips {
    param([string]$Category, [datetime]$Time, [string]$Text, [hashtable]$Context)
    if (-not $Text) { return }
    $matches = [regex]::Matches($Text, $IpRegex)
    foreach ($m in $matches) {
        $ip = $m.Value
        if ($ip -in @('0.0.0.0','127.0.0.1','::1')) { continue }
        $AllIpHits.Add([pscustomobject]@{
            IP       = $ip
            Category = $Category
            Time     = $Time
            Detail   = ($Context.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; '
        })
    }
}

Write-Host "=== SOC EVTX/IP Analysis starting ($Mode mode) ===" -ForegroundColor Cyan
Write-Host "Output folder: $OutputPath"

# ---------------------------------------------------------------------------
# 1. FAILED LOGONS / BRUTE FORCE  (Security 4625, 4771, 4776)
# ---------------------------------------------------------------------------
Write-Host "[1/11] Failed logons / brute force ..." -ForegroundColor Yellow
$failed = Invoke-LogQuery -LogName 'Security' -Id 4625,4771,4776 -FileHint 'Security'
$failedRows = foreach ($e in $failed) {
    $d = Get-EventXmlData $e
    $srcIp = $d['IpAddress']; if (-not $srcIp -or $srcIp -eq '-') { $srcIp = 'unknown' }
    Record-Ips -Category 'FailedLogon' -Time $e.TimeCreated -Text $srcIp -Context @{User=$d['TargetUserName']}
    [pscustomobject]@{
        Time     = $e.TimeCreated
        EventId  = $e.Id
        Account  = $d['TargetUserName']
        SourceIp = $srcIp
        Workstn  = $d['WorkstationName']
        FailureReason = $d['FailureReason']
        Status   = $d['Status']
    }
}
"=== FAILED LOGON EVENTS ($($failedRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'FailedLogons.txt')
$failedRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'FailedLogons.txt') -Append

$bruteForce = $failedRows | Where-Object { $_.SourceIp -ne 'unknown' } |
    Group-Object SourceIp | Where-Object { $_.Count -ge $FailedLogonThreshold } | Sort-Object Count -Descending
"`n=== PROBABLE BRUTE FORCE SOURCES (>= $FailedLogonThreshold failed attempts) ===" | Out-File (Join-Path $OutputPath 'FailedLogons.txt') -Append
foreach ($g in $bruteForce) {
    $accounts = ($g.Group.Account | Select-Object -Unique) -join ', '
    "IP: $($g.Name)  Attempts: $($g.Count)  Accounts targeted: $accounts" | Out-File (Join-Path $OutputPath 'FailedLogons.txt') -Append
}

# ---------------------------------------------------------------------------
# 2. SUCCESSFUL LOGONS incl. REMOTE / RDP / NETWORK  (Security 4624)
# ---------------------------------------------------------------------------
Write-Host "[2/11] Successful logons (incl. remote/RDP) ..." -ForegroundColor Yellow
$logonTypeMap = @{
  '2'='Interactive';'3'='Network';'4'='Batch';'5'='Service';'7'='Unlock';
  '8'='NetworkCleartext';'9'='NewCredentials';'10'='RemoteInteractive(RDP)';'11'='CachedInteractive'
}
$success = Invoke-LogQuery -LogName 'Security' -Id 4624 -FileHint 'Security'
$successRows = foreach ($e in $success) {
    $d = Get-EventXmlData $e
    $srcIp = $d['IpAddress']; if (-not $srcIp -or $srcIp -eq '-') { $srcIp = 'unknown' }
    Record-Ips -Category 'SuccessfulLogon' -Time $e.TimeCreated -Text $srcIp -Context @{User=$d['TargetUserName']; Type=$d['LogonType']}
    [pscustomobject]@{
        Time      = $e.TimeCreated
        Account   = $d['TargetUserName']
        Domain    = $d['TargetDomainName']
        LogonType = "$($d['LogonType']) - $($logonTypeMap[$d['LogonType']])"
        SourceIp  = $srcIp
        ProcessName = $d['ProcessName']
    }
}
"=== SUCCESSFUL LOGON EVENTS ($($successRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'SuccessfulLogons.txt')
$successRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'SuccessfulLogons.txt') -Append

$remote = $successRows | Where-Object { $_.LogonType -match '^(3|10)' -and $_.SourceIp -ne 'unknown' }
"`n=== REMOTE LOGONS (Network / RDP) - external-facing risk ===" | Out-File (Join-Path $OutputPath 'SuccessfulLogons.txt') -Append
$remote | Group-Object SourceIp | Sort-Object Count -Descending | ForEach-Object {
    "IP: $($_.Name)  Logons: $($_.Count)  Accounts: $(($_.Group.Account | Select-Object -Unique) -join ', ')" |
        Out-File (Join-Path $OutputPath 'SuccessfulLogons.txt') -Append
}

# ---------------------------------------------------------------------------
# 3. PRIVILEGE ESCALATION  (Security 4672 special privileges, 4648 explicit creds,
#    4728/4732/4756 group membership changes)
# ---------------------------------------------------------------------------
Write-Host "[3/11] Privilege escalation / sensitive privilege use ..." -ForegroundColor Yellow
$priv = Invoke-LogQuery -LogName 'Security' -Id 4672,4648,4728,4732,4756,4735 -FileHint 'Security'
$privRows = foreach ($e in $priv) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time    = $e.TimeCreated
        EventId = $e.Id
        Meaning = switch ($e.Id) {
            4672 {'Special/admin privileges assigned at logon'}
            4648 {'Logon using explicit credentials (possible lateral movement)'}
            4728 {'Member added to global security group'}
            4732 {'Member added to local security group (e.g. Administrators)'}
            4756 {'Member added to universal security group'}
            4735 {'Security-enabled group was changed'}
        }
        Account = $d['SubjectUserName']
        Target  = $d['TargetUserName']
        SourceIp= $d['IpAddress']
    }
}
"=== PRIVILEGE ESCALATION / SENSITIVE PRIVILEGE EVENTS ($($privRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'PrivilegeEscalation.txt')
$privRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'PrivilegeEscalation.txt') -Append

# ---------------------------------------------------------------------------
# 4. ACCOUNT MANAGEMENT / PERSISTENCE  (4720 new user, 4722 enabled, 4724 pw reset,
#    4738 account changed, 4726 deleted)
# ---------------------------------------------------------------------------
Write-Host "[4/11] Account creation / persistence ..." -ForegroundColor Yellow
$acct = Invoke-LogQuery -LogName 'Security' -Id 4720,4722,4723,4724,4726,4738,4740 -FileHint 'Security'
$acctRows = foreach ($e in $acct) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time    = $e.TimeCreated
        EventId = $e.Id
        Meaning = switch ($e.Id) {
            4720 {'USER ACCOUNT CREATED'}
            4722 {'User account enabled'}
            4723 {'Password change attempted'}
            4724 {'Password reset attempted'}
            4726 {'User account deleted'}
            4738 {'User account changed'}
            4740 {'Account locked out'}
        }
        TargetAccount = $d['TargetUserName']
        PerformedBy   = $d['SubjectUserName']
    }
}
"=== ACCOUNT MANAGEMENT / PERSISTENCE EVENTS ($($acctRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'AccountManagement.txt')
$acctRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'AccountManagement.txt') -Append
"`n>> New account creations (4720) are a top persistence indicator - review each one." |
    Out-File (Join-Path $OutputPath 'AccountManagement.txt') -Append

# ---------------------------------------------------------------------------
# 5. SERVICE INSTALLATION  (Security 4697, System 7045) - classic persistence
# ---------------------------------------------------------------------------
Write-Host "[5/11] New service installation ..." -ForegroundColor Yellow
$svcSec = Invoke-LogQuery -LogName 'Security' -Id 4697 -FileHint 'Security'
$svcSys = Invoke-LogQuery -LogName 'System'   -Id 7045 -FileHint 'System'
$svcRows = foreach ($e in @($svcSec + $svcSys)) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time        = $e.TimeCreated
        Log         = $e.LogName
        ServiceName = if ($d['ServiceName']) { $d['ServiceName'] } else { $d['0'] }
        ImagePath   = if ($d['ServiceFileName']) { $d['ServiceFileName'] } else { $d['ImagePath'] }
        Account     = $d['SubjectUserName']
    }
}
"=== NEW SERVICE INSTALLATION EVENTS ($($svcRows.Count) total) - check for unfamiliar binaries/paths ===" |
    Out-File (Join-Path $OutputPath 'ServiceInstallation.txt')
$svcRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'ServiceInstallation.txt') -Append

# ---------------------------------------------------------------------------
# 6. SCHEDULED TASKS  (Security 4698 created, 4699 deleted, 4700/4701 enabled/disabled)
# ---------------------------------------------------------------------------
Write-Host "[6/11] Scheduled task changes ..." -ForegroundColor Yellow
$task = Invoke-LogQuery -LogName 'Security' -Id 4698,4699,4700,4701 -FileHint 'Security'
$taskRows = foreach ($e in $task) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time    = $e.TimeCreated
        EventId = $e.Id
        Action  = switch ($e.Id) {4698{'Task CREATED'};4699{'Task DELETED'};4700{'Task ENABLED'};4701{'Task DISABLED'}}
        TaskName= $d['TaskName']
        Account = $d['SubjectUserName']
    }
}
"=== SCHEDULED TASK EVENTS ($($taskRows.Count) total) - common persistence mechanism ===" |
    Out-File (Join-Path $OutputPath 'ScheduledTasks.txt')
$taskRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'ScheduledTasks.txt') -Append

# ---------------------------------------------------------------------------
# 7. PROCESS CREATION (Security 4688 - requires command line auditing enabled)
# ---------------------------------------------------------------------------
Write-Host "[7/11] Process creation (4688) ..." -ForegroundColor Yellow
$proc = Invoke-LogQuery -LogName 'Security' -Id 4688 -FileHint 'Security'
$suspiciousTools = 'powershell|cmd\.exe|wscript|cscript|mshta|certutil|bitsadmin|regsvr32|rundll32|psexec|wmic|net\.exe|net1\.exe|whoami|nltest|vssadmin|schtasks|reg\.exe'
$procRows = foreach ($e in $proc) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time        = $e.TimeCreated
        NewProcess  = $d['NewProcessName']
        CommandLine = $d['CommandLine']
        ParentProc  = $d['ParentProcessName']
        Account     = $d['SubjectUserName']
    }
}
"=== PROCESS CREATION EVENTS ($($procRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'ProcessCreation.txt')
$procRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'ProcessCreation.txt') -Append
$sus = $procRows | Where-Object { $_.NewProcess -match $suspiciousTools -or $_.CommandLine -match $suspiciousTools }
"`n=== FLAGGED: living-off-the-land / dual-use tool executions ($($sus.Count)) ===" |
    Out-File (Join-Path $OutputPath 'ProcessCreation.txt') -Append
$sus | Format-Table Time,NewProcess,CommandLine,Account -AutoSize | Out-String -Width 300 |
    Out-File (Join-Path $OutputPath 'ProcessCreation.txt') -Append

# ---------------------------------------------------------------------------
# 8. POWERSHELL ACTIVITY (Script block logging 4104, module logging 4103,
#    classic PowerShell log 400/403)
# ---------------------------------------------------------------------------
Write-Host "[8/11] PowerShell script block activity ..." -ForegroundColor Yellow
$ps1 = Invoke-LogQuery -LogName 'Microsoft-Windows-PowerShell/Operational' -Id 4104,4103 -FileHint 'PowerShell'
$ps2 = Invoke-LogQuery -LogName 'Windows PowerShell' -Id 400,403,600 -FileHint 'PowerShell'
$psRows = foreach ($e in @($ps1 + $ps2)) {
    $d = Get-EventXmlData $e
    $scriptText = $d['ScriptBlockText']
    if ($scriptText) { Record-Ips -Category 'PowerShell' -Time $e.TimeCreated -Text $scriptText -Context @{Path=$d['Path']} }
    [pscustomobject]@{
        Time  = $e.TimeCreated
        Log   = $e.LogName
        Id    = $e.Id
        ScriptOrDetail = if ($scriptText) { ($scriptText -replace '\s+',' ').Substring(0,[Math]::Min(300,$scriptText.Length)) } else { $e.Message.Substring(0,[Math]::Min(200,$e.Message.Length)) }
    }
}
"=== POWERSHELL ACTIVITY EVENTS ($($psRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'PowerShellActivity.txt')
$psRows | Sort-Object Time | Format-List | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'PowerShellActivity.txt') -Append
$encoded = $psRows | Where-Object { $_.ScriptOrDetail -match '-enc|-e |FromBase64String|IEX|Invoke-Expression|DownloadString|Net\.WebClient|Invoke-WebRequest' }
"`n=== FLAGGED: encoded / download-cradle / IEX-style PowerShell ($($encoded.Count)) ===" |
    Out-File (Join-Path $OutputPath 'PowerShellActivity.txt') -Append
$encoded | Format-List | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'PowerShellActivity.txt') -Append

# ---------------------------------------------------------------------------
# 9. RDP / REMOTE DESKTOP SESSION ACTIVITY
#    (TerminalServices-RemoteConnectionManager 1149, LocalSessionManager 21/22/23/24/25)
# ---------------------------------------------------------------------------
Write-Host "[9/11] RDP session activity ..." -ForegroundColor Yellow
$rdp1 = Invoke-LogQuery -LogName 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational' -Id 1149 -FileHint 'RemoteConnectionManager'
$rdp2 = Invoke-LogQuery -LogName 'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational' -Id 21,22,23,24,25 -FileHint 'LocalSessionManager'
$rdpRows = foreach ($e in @($rdp1 + $rdp2)) {
    $d = Get-EventXmlData $e
    $ip = $d['IPString']; if (-not $ip) { $ip = $d['Address'] }
    if ($ip) { Record-Ips -Category 'RDP' -Time $e.TimeCreated -Text $ip -Context @{User=$d['User']} }
    [pscustomobject]@{
        Time  = $e.TimeCreated
        Id    = $e.Id
        Meaning = switch ($e.Id) {1149{'RDP auth succeeded'};21{'Session logon'};22{'Shell start'};23{'Session logoff'};24{'Session disconnected'};25{'Session reconnected'}}
        User  = $d['User']
        SourceIp = $ip
    }
}
"=== RDP SESSION EVENTS ($($rdpRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'RdpActivity.txt')
$rdpRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'RdpActivity.txt') -Append

# ---------------------------------------------------------------------------
# 10. LOG TAMPERING / ANTI-FORENSICS  (Security 1102 audit log cleared,
#     System 104 log cleared, 6005/6006/6008 unexpected shutdown)
# ---------------------------------------------------------------------------
Write-Host "[10/11] Log clearing / anti-forensics ..." -ForegroundColor Yellow
$clearSec = Invoke-LogQuery -LogName 'Security' -Id 1102 -FileHint 'Security'
$clearSys = Invoke-LogQuery -LogName 'System'   -Id 104  -FileHint 'System'
$clearRows = foreach ($e in @($clearSec + $clearSys)) {
    $d = Get-EventXmlData $e
    [pscustomobject]@{
        Time    = $e.TimeCreated
        Log     = $e.LogName
        Meaning = if ($e.Id -eq 1102) {'SECURITY AUDIT LOG WAS CLEARED'} else {'A log file was cleared'}
        Account = $d['SubjectUserName']
    }
}
"=== LOG CLEARING / ANTI-FORENSIC EVENTS ($($clearRows.Count) total) - HIGH SEVERITY if unexpected ===" |
    Out-File (Join-Path $OutputPath 'LogTampering.txt')
$clearRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'LogTampering.txt') -Append

# ---------------------------------------------------------------------------
# 11. SYSMON (optional, if installed) - process creation (1), network conn (3),
#     file create (11), registry (13), DNS (22)
# ---------------------------------------------------------------------------
Write-Host "[11/11] Sysmon activity (if present) ..." -ForegroundColor Yellow
$sysmon = Invoke-LogQuery -LogName 'Microsoft-Windows-Sysmon/Operational' -Id 1,3,11,13,22 -FileHint 'Sysmon'
if ($sysmon.Count -gt 0) {
    $sysRows = foreach ($e in $sysmon) {
        $d = Get-EventXmlData $e
        if ($d['DestinationIp']) { Record-Ips -Category 'SysmonNetwork' -Time $e.TimeCreated -Text $d['DestinationIp'] -Context @{Image=$d['Image']; Port=$d['DestinationPort']} }
        if ($d['SourceIp'])      { Record-Ips -Category 'SysmonNetwork' -Time $e.TimeCreated -Text $d['SourceIp'] -Context @{Image=$d['Image']} }
        [pscustomobject]@{
            Time   = $e.TimeCreated
            Id     = $e.Id
            Meaning= switch ($e.Id) {1{'Process create'};3{'Network connection'};11{'File create'};13{'Registry value set'};22{'DNS query'}}
            Image  = $d['Image']
            Detail = switch ($e.Id) {
                1 {$d['CommandLine']}
                3 {"$($d['SourceIp']):$($d['SourcePort']) -> $($d['DestinationIp']):$($d['DestinationPort'])"}
                11{$d['TargetFilename']}
                13{"$($d['TargetObject']) = $($d['Details'])"}
                22{"$($d['QueryName']) -> $($d['QueryResults'])"}
            }
        }
    }
    "=== SYSMON EVENTS ($($sysRows.Count) total) ===" | Out-File (Join-Path $OutputPath 'SysmonActivity.txt')
    $sysRows | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'SysmonActivity.txt') -Append
} else {
    "Sysmon log not found or empty - Sysmon may not be installed on this source." |
        Out-File (Join-Path $OutputPath 'SysmonActivity.txt')
}

# ---------------------------------------------------------------------------
# ALL EXTRACTED IPs - deduplicated, with hit counts and first/last seen
# ---------------------------------------------------------------------------
Write-Host "Compiling unique IP address report ..." -ForegroundColor Yellow
"=== ALL IP ADDRESSES OBSERVED ACROSS EVERY LOG CATEGORY ===" | Out-File (Join-Path $OutputPath 'AllExtractedIPs.txt')
$ipSummary = $AllIpHits | Group-Object IP | Sort-Object Count -Descending
foreach ($g in $ipSummary) {
    $first = ($g.Group | Sort-Object Time | Select-Object -First 1).Time
    $last  = ($g.Group | Sort-Object Time | Select-Object -Last 1).Time
    $cats  = ($g.Group.Category | Select-Object -Unique) -join ', '
    "IP: $($g.Name)  |  Hits: $($g.Count)  |  Categories: $cats  |  FirstSeen: $first  |  LastSeen: $last" |
        Out-File (Join-Path $OutputPath 'AllExtractedIPs.txt') -Append
}
"`n--- Full detail log ---" | Out-File (Join-Path $OutputPath 'AllExtractedIPs.txt') -Append
$AllIpHits | Sort-Object Time | Format-Table -AutoSize | Out-String -Width 300 | Out-File (Join-Path $OutputPath 'AllExtractedIPs.txt') -Append

# ---------------------------------------------------------------------------
# SUMMARY
# ---------------------------------------------------------------------------
$Elapsed = (Get-Date) - $StartTime
$summaryText = @"
=== SOC EVTX / IP ANALYSIS SUMMARY ===
Mode:                $Mode
Source:               $(if ($Mode -eq 'File') { $EvtxFolder } else { 'Local live event log' })
Window:               $(if ($Mode -eq 'Live') { "Last $DaysBack day(s)" } else { 'Full content of supplied .evtx files' })
Run completed:        $(Get-Date)
Elapsed:              $($Elapsed.ToString())

Failed logon events:            $($failedRows.Count)
Probable brute-force sources:   $($bruteForce.Count)
Successful logon events:        $($successRows.Count)
Remote (network/RDP) logons:    $($remote.Count)
Privilege escalation events:    $($privRows.Count)
Account management events:      $($acctRows.Count)
New service installs:           $($svcRows.Count)
Scheduled task changes:         $($taskRows.Count)
Process creation events:        $($procRows.Count)
  - Flagged LOLBin usage:       $($sus.Count)
PowerShell activity events:     $($psRows.Count)
  - Flagged encoded/IEX/DL:     $($encoded.Count)
RDP session events:             $($rdpRows.Count)
Log tampering events:           $($clearRows.Count)
Sysmon events:                  $($sysmon.Count)
Unique IP addresses observed:   $($ipSummary.Count)

Report files written to: $OutputPath
  FailedLogons.txt
  SuccessfulLogons.txt
  PrivilegeEscalation.txt
  AccountManagement.txt
  ServiceInstallation.txt
  ScheduledTasks.txt
  ProcessCreation.txt
  PowerShellActivity.txt
  RdpActivity.txt
  LogTampering.txt
  SysmonActivity.txt
  AllExtractedIPs.txt
  Summary.txt (this file)

NOTE: This is a read-only detection/triage aid, not a verdict. Flagged items
need human review - LOLBins, PowerShell, and remote logons are frequently
legitimate admin activity. Correlate counts/timing/accounts before escalating.
"@
$summaryText | Out-File (Join-Path $OutputPath 'Summary.txt')
Write-Host $summaryText -ForegroundColor Green
Write-Host "`n=== Done. Reports saved to: $OutputPath ===" -ForegroundColor Cyan
