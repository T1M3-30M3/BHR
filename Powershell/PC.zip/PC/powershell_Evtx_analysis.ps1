# ================================

# EVTX LOG ANALYSIS AUTOMATION

# Author: You 😎

# ================================

# Output directory

$BaseDir = "C:\EVTX_Analysis"
$TimeStamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$OutputDir = "$BaseDir$TimeStamp"

# Create directories

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

# Subfolders

$SecurityDir = "$OutputDir\Security"
$SystemDir   = "$OutputDir\System"
$PSDir       = "$OutputDir\PowerShell"

New-Item -ItemType Directory -Path $SecurityDir -Force | Out-Null
New-Item -ItemType Directory -Path $SystemDir -Force | Out-Null
New-Item -ItemType Directory -Path $PSDir -Force | Out-Null

Write-Host "[+] Output Directory: $OutputDir"

# ================================

# SECURITY LOG ANALYSIS

# ================================

Write-Host "[+] Collecting Security Logs..."

# Successful Logons

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624} -ErrorAction SilentlyContinue |
Out-File "$SecurityDir\logon_success.txt"

# Failed Logons

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625} -ErrorAction SilentlyContinue |
Out-File "$SecurityDir\failed_logons.txt"

# Admin Logins

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4672} -ErrorAction SilentlyContinue |
Out-File "$SecurityDir\admin_logins.txt"

# New User Created

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4720} -ErrorAction SilentlyContinue |
Out-File "$SecurityDir\new_users.txt"

# Brute Force Detection

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625} -ErrorAction SilentlyContinue |
Group-Object {$*.Properties[5].Value} |
Where-Object {$*.Count -gt 5} |
Out-File "$SecurityDir\bruteforce_users.txt"

# ================================

# SYSTEM LOG ANALYSIS

# ================================

Write-Host "[+] Collecting System Logs..."

# System Errors

Get-WinEvent -LogName System -ErrorAction SilentlyContinue |
Where-Object {$_.LevelDisplayName -eq "Error"} |
Out-File "$SystemDir\system_errors.txt"

# Service Installation (Persistence)

Get-WinEvent -FilterHashtable @{LogName='System'; Id=7045} -ErrorAction SilentlyContinue |
Out-File "$SystemDir\services_installed.txt"

# ================================

# POWERSHELL LOG ANALYSIS

# ================================

Write-Host "[+] Collecting PowerShell Logs..."

Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -ErrorAction SilentlyContinue |
Out-File "$PSDir\powershell_activity.txt"

# ================================

# LAST 24 HOURS ACTIVITY

# ================================

Write-Host "[+] Collecting Last 24h Logs..."

$StartTime = (Get-Date).AddDays(-1)

Get-WinEvent -FilterHashtable @{
LogName='Security'
StartTime=$StartTime
} -ErrorAction SilentlyContinue |
Out-File "$SecurityDir\last_24h.txt"

# ================================

# TOP ATTACKER IPs

# ================================

Write-Host "[+] Detecting Top Attacker IPs..."

Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625} -ErrorAction SilentlyContinue |
Select-Object -ExpandProperty Properties |
Where-Object {$_.Value -match "\d+.\d+.\d+.\d+"} |
Group-Object Value |
Sort-Object Count -Descending |
Select-Object -First 10 |
Out-File "$SecurityDir\top_attack_ips.txt"

# ================================

# OFFLINE EVTX SUPPORT (OPTIONAL)

# ================================

$EvtxPath = "C:\Logs\security.evtx"

if (Test-Path $EvtxPath) {
Write-Host "[+] Analyzing Offline EVTX..."

```
Get-WinEvent -Path $EvtxPath -ErrorAction SilentlyContinue |
Out-File "$OutputDir\offline_evtx_full.txt"

Get-WinEvent -Path $EvtxPath -FilterXPath "*[System[(EventID=4625)]]" -ErrorAction SilentlyContinue |
Out-File "$OutputDir\offline_failed_logons.txt"
```

}

# ================================

# DONE

# ================================

Write-Host "[+] Analysis Completed!"
Write-Host "[+] Results saved in: $OutputDir"
