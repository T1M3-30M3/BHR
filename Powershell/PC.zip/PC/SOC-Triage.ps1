﻿<#
.SYNOPSIS
    Windows Endpoint SOC Triage / Incident Response Collector

.DESCRIPTION
    Collects network, process, persistence, logon, and PowerShell-abuse
    artifacts into separate .txt files for offline SOC/DFIR review.
    Must be run as Administrator for full coverage (event logs, some
    WMI/Defender queries).

.NOTES
    - This script COLLECTS and FLAGS. It does not delete, kill, or block
      anything on its own - a human analyst should review 00_Summary.txt
      and 27_Correlation_Report.txt before taking any remediation action.
    - "Potential C2" labels are heuristic indicators (external IP, high
      connection count, unusual port, beaconing interval). They are NOT
      proof. Cross-check flagged IPs against threat intel (VirusTotal,
      AbuseIPDB, your TIP) before acting.

.USAGE
    Right-click PowerShell -> Run as Administrator
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

    Normal collection run:
        .\SOC-Triage.ps1

    First-time baseline snapshot (creates a reusable "known good" state):
        .\SOC-Triage.ps1 -Baseline

    Later run, diffed against that baseline (flags NEW processes/services/
    tasks/connections/users that weren't there before):
        .\SOC-Triage.ps1 -CompareBaseline
#>

#Requires -Version 5.1

param(
    [string]$OutputRoot = "$env:USERPROFILE\Desktop\SOC-Triage-$(Get-Date -Format 'yyyyMMdd_HHmmss')",
    [string]$BaselinePath = "$env:USERPROFILE\Desktop\SOC-Triage-Baseline",
    [switch]$Baseline,
    [switch]$CompareBaseline
)

# ------------------------------------------------------------------
# Setup
# ------------------------------------------------------------------
$ErrorActionPreference = 'SilentlyContinue'
New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$Alerts = New-Object System.Collections.Generic.List[string]
# Tracks paths of files already flagged suspicious elsewhere, so we hash them once at the end
$SuspiciousFilePaths = New-Object System.Collections.Generic.List[string]
# Tracks raw IOCs (ip/domain/hash/path/user) seen during this run
$IOCs = @{ IPs = New-Object System.Collections.Generic.List[string]
           Domains = New-Object System.Collections.Generic.List[string]
           Hashes = New-Object System.Collections.Generic.List[string]
           Files = New-Object System.Collections.Generic.List[string]
           Users = New-Object System.Collections.Generic.List[string] }
function Add-IOC { param([string]$Type, [string]$Value) if ($Value) { $IOCs[$Type].Add($Value) } }

function Write-Section {
    param([string]$File, [string]$Title, [scriptblock]$Content)
    $path = Join-Path $OutputRoot $File
    "==================== $Title ====================" | Out-File -FilePath $path -Encoding UTF8
    "Collected: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Out-File -FilePath $path -Append -Encoding UTF8
    "" | Out-File -FilePath $path -Append -Encoding UTF8
    try {
        & $Content | Out-File -FilePath $path -Append -Encoding UTF8 -Width 300
    } catch {
        "ERROR collecting this section: $($_.Exception.Message)" | Out-File -FilePath $path -Append -Encoding UTF8
    }
    Write-Host "[+] $File written"
}

function Add-Alert { param([string]$Msg) $Alerts.Add($Msg) }

Write-Host "=== SOC Triage Collector starting ===" -ForegroundColor Cyan
Write-Host "Output folder: $OutputRoot"
if (-not $isAdmin) {
    Write-Host "[!] NOT running as Administrator - Event Logs, some Defender/WMI data will be incomplete." -ForegroundColor Yellow
}

# ------------------------------------------------------------------
# 01. System Info
# ------------------------------------------------------------------
Write-Section -File "01_System_Info.txt" -Title "SYSTEM INFO" -Content {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    [PSCustomObject]@{
        Hostname       = $env:COMPUTERNAME
        Username       = $env:USERNAME
        Domain         = $cs.Domain
        OS             = $os.Caption
        Build          = $os.BuildNumber
        Architecture   = $os.OSArchitecture
        LastBootTime   = $os.LastBootUpTime
        UptimeHours    = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalHours,2)
        TimeZone       = (Get-TimeZone).Id
        RunningAsAdmin = $isAdmin
    } | Format-List
    "`n-- Environment Variables --"
    Get-ChildItem Env: | Format-Table -AutoSize
    "`n-- Installed Software --"
    Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*,
                      HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* |
        Where-Object { $_.DisplayName } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate |
        Sort-Object DisplayName | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 02. Network Configuration
# ------------------------------------------------------------------
Write-Section -File "02_Network_Config.txt" -Title "NETWORK CONFIGURATION" -Content {
    "-- IP Configuration --"
    Get-NetIPConfiguration | Format-List
    "`n-- Network Adapters --"
    Get-NetAdapter | Format-Table -AutoSize
    "`n-- ARP Table --"
    Get-NetNeighbor | Format-Table -AutoSize
    "`n-- Routing Table --"
    Get-NetRoute | Format-Table -AutoSize
    "`n-- DNS Servers --"
    Get-DnsClientServerAddress | Format-Table -AutoSize
    "`n-- Proxy Configuration --"
    netsh winhttp show proxy
    Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" |
        Select-Object ProxyEnable, ProxyServer, AutoConfigURL | Format-List
    "`n-- Firewall Profile Status --"
    Get-NetFirewallProfile | Format-Table Name, Enabled, DefaultInboundAction, DefaultOutboundAction -AutoSize
}

# ------------------------------------------------------------------
# 03. Active Connections + IP analysis (the part you asked about)
# ------------------------------------------------------------------
$connections = Get-NetTCPConnection -ErrorAction SilentlyContinue |
    Where-Object { $_.State -eq 'Established' -or $_.State -eq 'Listen' }

Write-Section -File "03_Active_Connections.txt" -Title "ACTIVE TCP CONNECTIONS" -Content {
    $connections | ForEach-Object {
        $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        [PSCustomObject]@{
            LocalAddress  = $_.LocalAddress
            LocalPort     = $_.LocalPort
            RemoteAddress = $_.RemoteAddress
            RemotePort    = $_.RemotePort
            State         = $_.State
            PID           = $_.OwningProcess
            ProcessName   = $proc.ProcessName
            ProcessPath   = $proc.Path
        }
    } | Sort-Object State, RemoteAddress | Format-Table -AutoSize
    "`n-- Listening UDP Ports --"
    Get-NetUDPEndpoint | ForEach-Object {
        $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        [PSCustomObject]@{ LocalAddress=$_.LocalAddress; LocalPort=$_.LocalPort; PID=$_.OwningProcess; ProcessName=$proc.ProcessName }
    } | Format-Table -AutoSize
}

# Top remote IPs by connection count
$remoteIps = $connections |
    Where-Object { $_.RemoteAddress -and $_.RemoteAddress -notin @('0.0.0.0','::','127.0.0.1','::1') } |
    Group-Object RemoteAddress |
    Sort-Object Count -Descending

Write-Section -File "04_Top_Remote_IPs.txt" -Title "TOP REMOTE IPS / POTENTIAL C2 INDICATORS" -Content {
    "NOTE: 'Potential' = heuristic flag only. Verify against threat intel before treating as confirmed C2.`n"

    $remoteIps | ForEach-Object {
        $ip = $_.Name
        $count = $_.Count
        $isPrivate = $ip -match '^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.|169\.254\.|::1|fe80:)'
        $procsForIp = ($_.Group | ForEach-Object {
            (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName
        } | Select-Object -Unique) -join ', '
        $ports = ($_.Group.RemotePort | Select-Object -Unique) -join ', '

        [PSCustomObject]@{
            RemoteIP        = $ip
            IsPrivateRange  = $isPrivate
            ConnectionCount = $count
            RemotePorts     = $ports
            OwningProcesses = $procsForIp
        }
    } | Format-Table -AutoSize

    "`n-- Flagged as suspicious (external IP + high reconnection count) --"
    foreach ($grp in $remoteIps) {
        $isPrivate = $grp.Name -match '^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.|169\.254\.|::1|fe80:)'
        if (-not $isPrivate -and $grp.Count -ge 5) {
            $procs = ($grp.Group | ForEach-Object { (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName } | Select-Object -Unique) -join ', '
            "  [!] $($grp.Name) - $($grp.Count) connections - processes: $procs"
            Add-Alert "Potential C2/beaconing indicator: $($grp.Name) had $($grp.Count) connections via [$procs]"
            Add-IOC -Type IPs -Value $grp.Name
        }
    }

    "`n-- Unusual / high-risk destination ports seen --"
    $riskyPorts = @(4444,1337,31337,6666,6667,8443,8081,9001,9050,443,53)
    $connections | Where-Object { $_.RemotePort -in $riskyPorts -and $_.RemoteAddress -notmatch '^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.)' } |
        Select-Object RemoteAddress, RemotePort, OwningProcess -Unique | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 05. DNS
# ------------------------------------------------------------------
Write-Section -File "05_DNS.txt" -Title "DNS CACHE" -Content {
    Get-DnsClientCache | Sort-Object Name | Format-Table Entry, Name, Data, TimeToLive -AutoSize
}

# ------------------------------------------------------------------
# 06. Processes
# ------------------------------------------------------------------
$allProcs = Get-CimInstance Win32_Process
$suspiciousDirs = 'AppData\\Local\\Temp|AppData\\Roaming|\\Downloads\\|\\Public\\|\$Recycle\.Bin'
$livingOffLand = 'powershell.exe|cmd.exe|wscript.exe|cscript.exe|mshta.exe|rundll32.exe|regsvr32.exe|certutil.exe|bitsadmin.exe'

Write-Section -File "06_Processes.txt" -Title "ALL RUNNING PROCESSES" -Content {
    $allProcs | Select-Object ProcessId, ParentProcessId, Name,
        @{n='User';e={ try { (Invoke-CimMethod -InputObject $_ -MethodName GetOwner).User } catch { 'N/A' } }},
        CreationDate, ExecutablePath, CommandLine |
        Sort-Object ProcessId | Format-List
}

Write-Section -File "07_Suspicious_Processes.txt" -Title "SUSPICIOUS PROCESS INDICATORS" -Content {
    "-- Processes running from suspicious directories (TEMP/AppData/Downloads/Public/RecycleBin) --"
    $flagged1 = $allProcs | Where-Object { $_.ExecutablePath -match $suspiciousDirs }
    $flagged1 | Select-Object ProcessId, Name, ExecutablePath, CommandLine | Format-List
    foreach ($p in $flagged1) {
        Add-Alert "Process running from suspicious path: $($p.Name) (PID $($p.ProcessId)) -> $($p.ExecutablePath)"
        if ($p.ExecutablePath) { $SuspiciousFilePaths.Add($p.ExecutablePath); Add-IOC -Type Files -Value $p.ExecutablePath }
    }

    "`n-- Unsigned executables among running processes --"
    $flagged2 = foreach ($p in $allProcs) {
        if ($p.ExecutablePath -and (Test-Path $p.ExecutablePath)) {
            $sig = Get-AuthenticodeSignature -FilePath $p.ExecutablePath -ErrorAction SilentlyContinue
            if ($sig.Status -ne 'Valid') {
                [PSCustomObject]@{ PID=$p.ProcessId; Name=$p.Name; Path=$p.ExecutablePath; SignatureStatus=$sig.Status }
            }
        }
    }
    $flagged2 | Format-Table -AutoSize
    foreach ($p in $flagged2) {
        Add-Alert "Unsigned/invalid-signature binary running: $($p.Name) (PID $($p.PID)) - $($p.SignatureStatus)"
        if ($p.Path) { $SuspiciousFilePaths.Add($p.Path); Add-IOC -Type Files -Value $p.Path }
    }

    "`n-- Living-off-the-land binaries currently running (review command lines) --"
    $allProcs | Where-Object { $_.Name -match $livingOffLand } |
        Select-Object ProcessId, Name, CommandLine | Format-List

    "`n-- Encoded / obfuscated PowerShell command lines --"
    $encFlags = $allProcs | Where-Object {
        $_.Name -match 'powershell' -and $_.CommandLine -match '-enc|-EncodedCommand|IEX|DownloadString|DownloadFile|Invoke-WebRequest|Invoke-RestMethod|FromBase64String|-nop\b|-w hidden|-windowstyle hidden'
    }
    $encFlags | Select-Object ProcessId, CommandLine | Format-List
    foreach ($p in $encFlags) {
        Add-Alert "Suspicious PowerShell command line (PID $($p.ProcessId)): $($p.CommandLine)"
        if ($p.CommandLine) {
            [regex]::Matches($p.CommandLine, '\b\d{1,3}(\.\d{1,3}){3}\b') | ForEach-Object { Add-IOC -Type IPs -Value $_.Value }
            [regex]::Matches($p.CommandLine, 'https?://([a-zA-Z0-9\.\-]+)') | ForEach-Object { Add-IOC -Type Domains -Value $_.Groups[1].Value }
        }
    }
}

# ------------------------------------------------------------------
# 08. Scheduled Tasks (incl. hidden)
# ------------------------------------------------------------------
Write-Section -File "08_Scheduled_Tasks.txt" -Title "SCHEDULED TASKS (ALL)" -Content {
    Get-ScheduledTask | ForEach-Object {
        $info = Get-ScheduledTaskInfo -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue
        [PSCustomObject]@{
            TaskName    = $_.TaskName
            TaskPath    = $_.TaskPath
            State       = $_.State
            Author      = $_.Author
            LastRunTime = $info.LastRunTime
            NextRunTime = $info.NextRunTime
            Actions     = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
        }
    } | Sort-Object TaskPath | Format-Table -AutoSize
}

Write-Section -File "09_Hidden_Scheduled_Tasks.txt" -Title "HIDDEN / RECENTLY CREATED SCHEDULED TASKS" -Content {
    "-- Tasks with the Hidden flag set --"
    # 'Hidden' isn't exposed directly by Get-ScheduledTask; read it from the task XML/registry
    $hidden = Get-ScheduledTask | Where-Object {
        ([xml](Export-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue)).Task.Settings.Hidden -eq 'true'
    }
    $hidden | Select-Object TaskName, TaskPath, State | Format-Table -AutoSize
    foreach ($t in $hidden) { Add-Alert "Hidden scheduled task found: $($t.TaskPath)$($t.TaskName)" }

    "`n-- Tasks registered in the last 14 days (via Task Scheduler registry key timestamps) --"
    $taskKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree"
    Get-ChildItem -Path $taskKey -Recurse -ErrorAction SilentlyContinue |
        ForEach-Object {
            $item = Get-Item $_.PSPath -ErrorAction SilentlyContinue
            [PSCustomObject]@{ Path = $_.PSPath; LastWrite = $item.LastWriteTime }
        } | Where-Object { $_.LastWrite -gt (Get-Date).AddDays(-14) } |
        Sort-Object LastWrite -Descending | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 10. Services
# ------------------------------------------------------------------
Write-Section -File "10_Services.txt" -Title "SERVICES" -Content {
    Get-CimInstance Win32_Service |
        Select-Object Name, DisplayName, State, StartMode, PathName, StartName |
        Sort-Object State, Name | Format-Table -AutoSize

    "`n-- Non-Microsoft services with unusual paths (Temp/AppData/Users) --"
    Get-CimInstance Win32_Service | Where-Object {
        $_.PathName -match 'AppData|\\Temp\\|\\Users\\' -and $_.PathName -notmatch 'Program Files'
    } | Select-Object Name, DisplayName, PathName, StartName | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 11. Persistence
# ------------------------------------------------------------------
Write-Section -File "11_Persistence.txt" -Title "PERSISTENCE MECHANISMS" -Content {
    "-- Registry Run / RunOnce (HKLM & HKCU) --"
    $runKeys = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
    )
    foreach ($k in $runKeys) {
        "`n[$k]"
        Get-ItemProperty -Path $k -ErrorAction SilentlyContinue | Format-List
    }

    "`n-- Startup Folder Items --"
    Get-ChildItem "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp",
                   "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup" -ErrorAction SilentlyContinue |
        Select-Object FullName, LastWriteTime | Format-Table -AutoSize

    "`n-- WMI Permanent Event Subscriptions --"
    Get-CimInstance -Namespace root\subscription -ClassName __EventFilter -ErrorAction SilentlyContinue | Format-List
    Get-CimInstance -Namespace root\subscription -ClassName CommandLineEventConsumer -ErrorAction SilentlyContinue | Format-List
    Get-CimInstance -Namespace root\subscription -ClassName __FilterToConsumerBinding -ErrorAction SilentlyContinue | Format-List

    "`n-- Logon Scripts (GPO/User) --"
    Get-ItemProperty 'HKCU:\Environment' -Name UserInitMprLogonScript -ErrorAction SilentlyContinue | Format-List

    "`n-- Recently Installed / Modified Services (last 14 days by registry key write time) --"
    Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $item = Get-Item $_.PSPath -ErrorAction SilentlyContinue
            [PSCustomObject]@{ Service = $_.PSChildName; LastWrite = $item.LastWriteTime }
        } | Where-Object { $_.LastWrite -gt (Get-Date).AddDays(-14) } |
        Sort-Object LastWrite -Descending | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 12. Users & Logons
# ------------------------------------------------------------------
Write-Section -File "12_Users.txt" -Title "LOCAL USERS & GROUPS" -Content {
    "-- Local Users --"
    Get-LocalUser | Format-Table Name, Enabled, LastLogon, PasswordLastSet -AutoSize
    "`n-- Local Administrators Group --"
    Get-LocalGroupMember -Group "Administrators" | Format-Table -AutoSize
    "`n-- Currently Logged-On Users / Sessions --"
    query user 2>$null
    quser 2>$null
}

Write-Section -File "13_Logon_Events.txt" -Title "LOGON / ACCOUNT EVENTS (Security Log)" -Content {
    if (-not $isAdmin) { "Run as Administrator to collect this section."; return }
    $ids = 4624,4625,4648,4672,4720,4732,4697,4698,4702
    Get-WinEvent -FilterHashtable @{LogName='Security'; Id=$ids; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, Id, @{n='Account';e={$_.Properties[5].Value}}, @{n='SourceIP';e={$_.Properties[18].Value}} -ErrorAction SilentlyContinue |
        Sort-Object TimeCreated -Descending | Format-Table -AutoSize

    "`n-- Failed Logon Count by Source IP (last 7 days) --"
    $fails = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue
    $fails | ForEach-Object { $_.Properties[19].Value } | Group-Object | Sort-Object Count -Descending | Format-Table Name, Count -AutoSize
    $bruteforce = $fails | ForEach-Object { $_.Properties[19].Value } | Group-Object | Where-Object { $_.Count -ge 10 }
    foreach ($b in $bruteforce) { Add-Alert "Possible brute-force: $($b.Count) failed logons from source $($b.Name)" }

    "`n-- RDP Logon Events (Event ID 4624, LogonType 10) --"
    Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue |
        Where-Object { $_.Properties[8].Value -eq 10 } |
        Select-Object TimeCreated, @{n='Account';e={$_.Properties[5].Value}}, @{n='SourceIP';e={$_.Properties[18].Value}} |
        Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 14. PowerShell-specific artifacts
# ------------------------------------------------------------------
Write-Section -File "14_PowerShell_Artifacts.txt" -Title "POWERSHELL CONFIG & HISTORY" -Content {
    "PowerShell Version: $($PSVersionTable.PSVersion)"
    "Execution Policy: $(Get-ExecutionPolicy -List | Out-String)"

    "`n-- Script Block / Module Logging Config --"
    Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -ErrorAction SilentlyContinue | Format-List
    Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging' -ErrorAction SilentlyContinue | Format-List
    Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription' -ErrorAction SilentlyContinue | Format-List

    "`n-- Console History (current user) --"
    $histPath = (Get-PSReadlineOption).HistorySavePath
    if (Test-Path $histPath) { Get-Content $histPath }

    "`n-- PowerShell Operational Log: Encoded / Download / IEX events (last 7 days) --"
    if ($isAdmin) {
        Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PowerShell/Operational'; Id=4104; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -match 'DownloadString|DownloadFile|IEX|Invoke-Expression|FromBase64String|-enc' } |
            Select-Object TimeCreated, Message | Format-List
    } else { "Run as Administrator to collect this section." }
}

# ------------------------------------------------------------------
# 15. Windows Defender / Firewall
# ------------------------------------------------------------------
Write-Section -File "15_Defender_Firewall.txt" -Title "SECURITY PRODUCT STATUS" -Content {
    "-- Windows Defender Status --"
    Get-MpComputerStatus | Format-List
    "`n-- Defender Exclusions --"
    Get-MpPreference | Select-Object ExclusionPath, ExclusionExtension, ExclusionProcess | Format-List
    "`n-- Recent Defender Detections --"
    Get-MpThreatDetection | Format-Table -AutoSize
    "`n-- Firewall Rules (enabled, inbound allow) --"
    Get-NetFirewallRule -Enabled True -Direction Inbound -Action Allow |
        Select-Object DisplayName, Profile | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 16. File Artifact Triage
# ------------------------------------------------------------------
Write-Section -File "16_Recent_File_Artifacts.txt" -Title "RECENTLY MODIFIED / SUSPICIOUS FILES" -Content {
    $searchRoots = @("$env:TEMP", "$env:APPDATA", "$env:LOCALAPPDATA", "$env:USERPROFILE\Downloads", "C:\Users\Public")
    $exts = '*.exe','*.dll','*.ps1','*.bat','*.vbs','*.js','*.hta'
    foreach ($root in $searchRoots) {
        if (Test-Path $root) {
            "`n-- $root (modified last 7 days) --"
            Get-ChildItem -Path $root -Include $exts -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
                Select-Object FullName, LastWriteTime, Length | Sort-Object LastWriteTime -Descending | Format-Table -AutoSize
        }
    }

    "`n-- Recycle Bin Contents --"
    Get-ChildItem 'C:\$Recycle.Bin' -Recurse -Force -ErrorAction SilentlyContinue |
        Select-Object FullName, LastWriteTime | Format-Table -AutoSize

    "`n-- Prefetch Files (last 7 days) --"
    Get-ChildItem "$env:WINDIR\Prefetch" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) } |
        Select-Object Name, LastWriteTime | Sort-Object LastWriteTime -Descending | Format-Table -AutoSize
}

# ------------------------------------------------------------------
# 17. Key Event Logs (bulk dump, last 3 days)
# ------------------------------------------------------------------
Write-Section -File "17_Event_Logs_Overview.txt" -Title "KEY EVENT LOGS (LAST 3 DAYS, ERROR/WARNING/CRITICAL)" -Content {
    if (-not $isAdmin) { "Run as Administrator to collect this section."; return }
    foreach ($log in 'System','Application','Microsoft-Windows-TaskScheduler/Operational','Microsoft-Windows-Windows Defender/Operational') {
        "`n===== $log ====="
        Get-WinEvent -FilterHashtable @{LogName=$log; StartTime=(Get-Date).AddDays(-3)} -ErrorAction SilentlyContinue |
            Where-Object { $_.LevelDisplayName -in @('Error','Warning','Critical') } |
            Select-Object TimeCreated, LevelDisplayName, Id, Message |
            Sort-Object TimeCreated -Descending | Select-Object -First 100 | Format-List
    }
}

# ------------------------------------------------------------------
# 19. Process Tree + Loaded Modules for suspicious processes only
#     (doing this for every process on the box would be huge and mostly noise)
# ------------------------------------------------------------------
Write-Section -File "19_Process_Tree_And_Modules.txt" -Title "PROCESS TREE (SUSPICIOUS PROCESSES) + LOADED MODULES" -Content {
    $suspiciousPids = @()
    $suspiciousPids += ($allProcs | Where-Object { $_.ExecutablePath -match $suspiciousDirs }).ProcessId
    $suspiciousPids += ($allProcs | Where-Object { $_.Name -match $livingOffLand -and $_.CommandLine -match '-enc|IEX|DownloadString|FromBase64String' }).ProcessId
    $suspiciousPids = $suspiciousPids | Select-Object -Unique

    if (-not $suspiciousPids) { "No suspicious processes identified in this run - nothing to build a tree for." }

    foreach ($spid in $suspiciousPids) {
        $proc = $allProcs | Where-Object { $_.ProcessId -eq $spid }
        if (-not $proc) { continue }
        "`n===== PID $spid : $($proc.Name) ====="
        "Path: $($proc.ExecutablePath)"
        "CommandLine: $($proc.CommandLine)"

        "`n-- Ancestry (parent chain) --"
        $cur = $proc
        $depth = 0
        while ($cur -and $depth -lt 6) {
            "  " * $depth + "-> $($cur.Name) (PID $($cur.ProcessId), PPID $($cur.ParentProcessId))"
            $cur = $allProcs | Where-Object { $_.ProcessId -eq $cur.ParentProcessId }
            $depth++
        }

        "`n-- Children --"
        $allProcs | Where-Object { $_.ParentProcessId -eq $spid } |
            ForEach-Object { "  -> $($_.Name) (PID $($_.ProcessId)) : $($_.CommandLine)" }

        "`n-- Integrity Level / Token (best-effort) --"
        try {
            $liveProc = Get-Process -Id $spid -ErrorAction Stop
            "  64-bit: $(-not $liveProc.Modules[0].FileName -match 'SysWOW64')"
        } catch { "  Process exited before token could be inspected." }

        "`n-- Loaded Modules/DLLs --"
        try {
            (Get-Process -Id $spid -ErrorAction Stop).Modules |
                Select-Object ModuleName, FileName, Company | Format-Table -AutoSize
        } catch { "  Unable to enumerate modules (process exited or access denied)." }
    }
}

# ------------------------------------------------------------------
# 20. USB & External Devices
# ------------------------------------------------------------------
Write-Section -File "20_USB_Devices.txt" -Title "USB / EXTERNAL DEVICE HISTORY" -Content {
    "-- Currently Connected USB Devices --"
    Get-CimInstance Win32_USBControllerDevice -ErrorAction SilentlyContinue | ForEach-Object {
        [wmi]($_.Dependent)
    } | Select-Object Name, DeviceID, Status | Format-Table -AutoSize

    "`n-- USB Storage Device History (registry) --"
    Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR' -ErrorAction SilentlyContinue |
        ForEach-Object {
            Get-ChildItem $_.PSPath | ForEach-Object {
                $props = Get-ItemProperty $_.PSPath
                [PSCustomObject]@{
                    DeviceDesc = $props.FriendlyName
                    SerialKey  = $_.PSChildName
                    FirstInstallLastWrite = (Get-Item $_.PSPath).LastWriteTime
                }
            }
        } | Format-Table -AutoSize

    "`n-- Mounted Volumes / Drive Letters --"
    Get-Volume | Format-Table DriveLetter, FileSystemLabel, FileSystem, DriveType, SizeRemaining, Size -AutoSize

    "`n-- Recent Device Insertion/Removal Events (Event ID 2003/2100/2101, if present) --"
    if ($isAdmin) {
        Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-DriverFrameworks-UserMode/Operational'; StartTime=(Get-Date).AddDays(-14)} -ErrorAction SilentlyContinue |
            Select-Object TimeCreated, Id, Message | Sort-Object TimeCreated -Descending | Format-List
    } else { "Run as Administrator to collect device events." }
}

# ------------------------------------------------------------------
# 21. Remote Access Surface
# ------------------------------------------------------------------
Write-Section -File "21_Remote_Access.txt" -Title "REMOTE ACCESS CONFIGURATION" -Content {
    "-- RDP Enabled/Disabled --"
    Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -ErrorAction SilentlyContinue
    "`n-- RDP Port --"
    Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name PortNumber -ErrorAction SilentlyContinue
    "`n-- RDP Client Connection History (this user) --"
    Get-ItemProperty 'HKCU:\Software\Microsoft\Terminal Server Client\Servers\*' -ErrorAction SilentlyContinue | Select-Object PSChildName, UsernameHint

    "`n-- WinRM Configuration & Listeners --"
    winrm get winrm/config 2>$null
    winrm enumerate winrm/config/listener 2>$null

    "`n-- SMB Configuration --"
    Get-SmbServerConfiguration | Select-Object EnableSMB1Protocol, EnableSMB2Protocol | Format-List
    "`n-- Active SMB Sessions --"
    Get-SmbSession | Format-Table -AutoSize
    "`n-- SMB Shares (incl. administrative shares) --"
    Get-SmbShare | Format-Table Name, Path, Description -AutoSize
}

# ------------------------------------------------------------------
# 22. Registry Deep Dive (classic hijack/persistence points)
# ------------------------------------------------------------------
Write-Section -File "22_Registry_Deep_Dive.txt" -Title "REGISTRY SECURITY CONFIGURATION" -Content {
    "-- AppInit_DLLs (DLL injection into every GUI process) --"
    Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows' -Name AppInit_DLLs, LoadAppInit_DLLs -ErrorAction SilentlyContinue | Format-List

    "`n-- Image File Execution Options (debugger-hijack persistence) --"
    Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $dbg = Get-ItemProperty $_.PSPath -Name Debugger -ErrorAction SilentlyContinue
            if ($dbg.Debugger) { [PSCustomObject]@{ Target = $_.PSChildName; Debugger = $dbg.Debugger } }
        } | Format-Table -AutoSize

    "`n-- Winlogon Shell / Userinit (should be explorer.exe / userinit.exe only) --"
    Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name Shell, Userinit -ErrorAction SilentlyContinue | Format-List

    "`n-- LSA Authentication Packages / Security Providers --"
    Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'Security Packages','Authentication Packages','Notification Packages' -ErrorAction SilentlyContinue | Format-List
    "`n-- LSA Protection (RunAsPPL) / Credential Guard --"
    Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name RunAsPPL -ErrorAction SilentlyContinue
    (Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning
}

# ------------------------------------------------------------------
# 23. Domain / Active Directory context (only if domain-joined)
# ------------------------------------------------------------------
Write-Section -File "23_Domain_Info.txt" -Title "DOMAIN / ACTIVE DIRECTORY CONTEXT" -Content {
    $cs = Get-CimInstance Win32_ComputerSystem
    if (-not $cs.PartOfDomain) { "This machine is not domain-joined (workgroup: $($cs.Workgroup))."; return }
    "Domain: $($cs.Domain)"
    "`n-- Domain Controller --"
    ([ADSI]"LDAP://RootDSE").dnsHostName
    "`n-- Domain Groups This Computer Account Belongs To --"
    whoami /groups 2>$null
    "`n-- Applied Group Policies --"
    gpresult /r 2>$null
}

# ------------------------------------------------------------------
# 24. Anti-Forensics / Defense Evasion Indicators
# ------------------------------------------------------------------
Write-Section -File "24_Anti_Forensics_Indicators.txt" -Title "DEFENSE EVASION / ANTI-FORENSICS INDICATORS" -Content {
    if (-not $isAdmin) { "Run as Administrator to collect this section."; return }

    "-- Event Log Cleared (Event ID 1102 / 104) --"
    $cleared = Get-WinEvent -FilterHashtable @{LogName='Security','System'; Id=1102,104; StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue
    $cleared | Select-Object TimeCreated, LogName, Id, @{n='User';e={$_.UserId}} | Format-Table -AutoSize
    foreach ($c in $cleared) { Add-Alert "Event log was CLEARED on $($c.TimeCreated) (Log: $($c.LogName)) - strong anti-forensics indicator" }

    "`n-- Audit Policy Changes (Event ID 4719) --"
    Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4719; StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, Message | Format-List

    "`n-- Windows Defender Real-Time Protection Disabled (Event ID 5001) --"
    $defOff = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational'; Id=5001; StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue
    $defOff | Select-Object TimeCreated, Message | Format-List
    foreach ($d in $defOff) { Add-Alert "Windows Defender real-time protection was disabled at $($d.TimeCreated)" }

    "`n-- Firewall Disabled Events (Event ID 4950/4954) --"
    Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4950,4954; StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, Message | Format-List

    "`n-- Scheduled Task / Service Deletion (Event ID 4699 task deleted, 7040 service state change) --"
    Get-WinEvent -FilterHashtable @{LogName='Security','System'; Id=4699,7040; StartTime=(Get-Date).AddDays(-14)} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, LogName, Id, Message | Format-List

    "`n-- Volume Shadow Copy Deletion (a strong ransomware/anti-forensics indicator) --"
    Get-WinEvent -FilterHashtable @{LogName='Application'; Id=8224; StartTime=(Get-Date).AddDays(-14)} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, Message | Format-List
    $vssDeleted = $allProcs | Where-Object { $_.CommandLine -match 'vssadmin.*delete|wmic.*shadowcopy.*delete' }
    foreach ($v in $vssDeleted) { Add-Alert "Shadow copy deletion command observed: $($v.CommandLine)" }
}

# ------------------------------------------------------------------
# 25. File Hashes for everything flagged suspicious elsewhere in this run
# ------------------------------------------------------------------
Write-Section -File "25_Suspicious_File_Hashes.txt" -Title "FILE INTEGRITY - HASHES OF FLAGGED FILES" -Content {
    $unique = $SuspiciousFilePaths | Select-Object -Unique
    if (-not $unique) { "No files were flagged as suspicious elsewhere in this run."; return }

    foreach ($path in $unique) {
        if (Test-Path $path) {
            $item = Get-Item $path
            $sha256 = Get-FileHash -Path $path -Algorithm SHA256 -ErrorAction SilentlyContinue
            $sig = Get-AuthenticodeSignature -FilePath $path -ErrorAction SilentlyContinue
            $vi = $item.VersionInfo
            [PSCustomObject]@{
                Path             = $path
                SizeBytes        = $item.Length
                Created          = $item.CreationTime
                Modified         = $item.LastWriteTime
                LastAccessed     = $item.LastAccessTime
                SHA256           = $sha256.Hash
                SignatureStatus  = $sig.Status
                CertPublisher    = $sig.SignerCertificate.Subject
                OriginalFilename = $vi.OriginalFilename
                CompanyName      = $vi.CompanyName
                ProductName      = $vi.ProductName
            } | Format-List
            Add-IOC -Type Hashes -Value $sha256.Hash
        } else {
            "Path no longer exists (process may have deleted itself): $path"
        }
    }
}

# ------------------------------------------------------------------
# 26. Consolidated IOC Extraction
# ------------------------------------------------------------------
Write-Section -File "26_IOC_Extraction.txt" -Title "EXTRACTED INDICATORS OF COMPROMISE (this run)" -Content {
    "-- IPv4 Addresses --"
    $IOCs.IPs | Select-Object -Unique | Sort-Object
    "`n-- Domains --"
    $IOCs.Domains | Select-Object -Unique | Sort-Object
    "`n-- File Hashes (SHA256) --"
    $IOCs.Hashes | Select-Object -Unique | Sort-Object
    "`n-- Suspicious File Paths --"
    $IOCs.Files | Select-Object -Unique | Sort-Object
    "`n`nNOTE: These are indicators observed on THIS host during THIS run. They are leads for"
    "threat-intel enrichment (VirusTotal/AbuseIPDB/etc.), not confirmed malicious artifacts."
}

# ------------------------------------------------------------------
# 27. Correlation Report - ties process/network/persistence together
#     per suspicious process, instead of leaving it spread across files
# ------------------------------------------------------------------
Write-Section -File "27_Correlation_Report.txt" -Title "CORRELATION REPORT (suspicious process -> network -> persistence)" -Content {
    $suspiciousPids = @()
    $suspiciousPids += ($allProcs | Where-Object { $_.ExecutablePath -match $suspiciousDirs }).ProcessId
    $suspiciousPids += ($allProcs | Where-Object { $_.Name -match $livingOffLand -and $_.CommandLine -match '-enc|IEX|DownloadString|FromBase64String' }).ProcessId
    $suspiciousPids = $suspiciousPids | Select-Object -Unique

    if (-not $suspiciousPids) { "No suspicious processes identified - nothing to correlate."; return }

    foreach ($spid in $suspiciousPids) {
        $proc = $allProcs | Where-Object { $_.ProcessId -eq $spid }
        $parent = $allProcs | Where-Object { $_.ProcessId -eq $proc.ParentProcessId }
        $netConns = $connections | Where-Object { $_.OwningProcess -eq $spid }
        $tasksReferencing = Get-ScheduledTask | Where-Object {
            ($_.Actions | ForEach-Object { $_.Execute }) -join ' ' -match [regex]::Escape($proc.Name)
        }

        @"
$($proc.Name) (PID $spid)
  |
  +---- Parent: $($parent.Name) (PID $($parent.ProcessId)) - CmdLine: $($parent.CommandLine)
  |
  +---- CommandLine: $($proc.CommandLine)
  |
  +---- Network:
$(if ($netConns) { ($netConns | ForEach-Object { "  |       +---- $($_.RemoteAddress):$($_.RemotePort) [$($_.State)]" }) -join "`r`n" } else { "  |       +---- (no active connections observed)" })
  |
  +---- File: $($proc.ExecutablePath)
  |
  +---- Persistence:
$(if ($tasksReferencing) { ($tasksReferencing | ForEach-Object { "  |       +---- Scheduled Task: $($_.TaskPath)$($_.TaskName)" }) -join "`r`n" } else { "  |       +---- (no matching scheduled task found)" })

"@
    }
}

# ------------------------------------------------------------------
# 28. Baseline capture / compare mode
# ------------------------------------------------------------------
if ($Baseline) {
    New-Item -ItemType Directory -Path $BaselinePath -Force | Out-Null
    ($allProcs | Select-Object Name, ExecutablePath | Sort-Object Name -Unique) | Export-Csv "$BaselinePath\processes.csv" -NoTypeInformation
    (Get-CimInstance Win32_Service | Select-Object Name, PathName | Sort-Object Name) | Export-Csv "$BaselinePath\services.csv" -NoTypeInformation
    ($connections | Select-Object RemoteAddress, RemotePort -Unique) | Export-Csv "$BaselinePath\connections.csv" -NoTypeInformation
    (Get-ScheduledTask | Select-Object TaskName, TaskPath) | Export-Csv "$BaselinePath\tasks.csv" -NoTypeInformation
    (Get-LocalUser | Select-Object Name) | Export-Csv "$BaselinePath\users.csv" -NoTypeInformation
    Write-Host "[+] Baseline snapshot saved to $BaselinePath - re-run later with -CompareBaseline" -ForegroundColor Green
}

if ($CompareBaseline) {
    Write-Section -File "28_Baseline_Diff.txt" -Title "BASELINE DIFF - WHAT'S NEW SINCE LAST SNAPSHOT" -Content {
        if (-not (Test-Path $BaselinePath)) { "No baseline found at $BaselinePath. Run with -Baseline first."; return }

        $baseProcs = Import-Csv "$BaselinePath\processes.csv" -ErrorAction SilentlyContinue
        $newProcs = ($allProcs | Select-Object Name, ExecutablePath -Unique) | Where-Object { $_.Name -notin $baseProcs.Name }
        "-- NEW PROCESSES (not seen in baseline) --"
        $newProcs | Format-Table -AutoSize
        foreach ($n in $newProcs) { Add-Alert "New process since baseline: $($n.Name) -> $($n.ExecutablePath)" }

        $baseSvcs = Import-Csv "$BaselinePath\services.csv" -ErrorAction SilentlyContinue
        $newSvcs = (Get-CimInstance Win32_Service | Select-Object Name, PathName) | Where-Object { $_.Name -notin $baseSvcs.Name }
        "`n-- NEW SERVICES --"
        $newSvcs | Format-Table -AutoSize
        foreach ($n in $newSvcs) { Add-Alert "New service since baseline: $($n.Name) -> $($n.PathName)" }

        $baseTasks = Import-Csv "$BaselinePath\tasks.csv" -ErrorAction SilentlyContinue
        $newTasks = (Get-ScheduledTask | Select-Object TaskName, TaskPath) | Where-Object { $_.TaskName -notin $baseTasks.TaskName }
        "`n-- NEW SCHEDULED TASKS --"
        $newTasks | Format-Table -AutoSize
        foreach ($n in $newTasks) { Add-Alert "New scheduled task since baseline: $($n.TaskPath)$($n.TaskName)" }

        $baseUsers = Import-Csv "$BaselinePath\users.csv" -ErrorAction SilentlyContinue
        $newUsers = (Get-LocalUser | Select-Object Name) | Where-Object { $_.Name -notin $baseUsers.Name }
        "`n-- NEW LOCAL USERS --"
        $newUsers | Format-Table -AutoSize
        foreach ($n in $newUsers) { Add-Alert "New local user account since baseline: $($n.Name)" }

        $baseConns = Import-Csv "$BaselinePath\connections.csv" -ErrorAction SilentlyContinue
        $newConns = ($connections | Select-Object RemoteAddress, RemotePort -Unique) | Where-Object { $_.RemoteAddress -notin $baseConns.RemoteAddress }
        "`n-- NEW REMOTE IPS (not contacted at baseline time) --"
        $newConns | Format-Table -AutoSize
    }
}

# ------------------------------------------------------------------
# 18. Summary + Indicators + Alerts (this is the "SOC brain" file)
# ------------------------------------------------------------------
$riskLevel = if ($Alerts.Count -ge 5) { "HIGH" } elseif ($Alerts.Count -ge 1) { "MEDIUM" } else { "LOW" }

$summaryPath = Join-Path $OutputRoot "00_Summary.txt"
@"
========================================
 WINDOWS SOC TRIAGE SUMMARY
========================================
Host: $env:COMPUTERNAME
User: $env:USERNAME
Collected: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Ran as Administrator: $isAdmin

Risk Level (heuristic, NOT a verdict): $riskLevel
Total indicators flagged: $($Alerts.Count)

----------------------------------------
INDICATORS / ALERTS
----------------------------------------
$(if ($Alerts.Count -eq 0) { "No automated indicators triggered. This does NOT mean the host is clean - review all files manually." } else { ($Alerts | ForEach-Object { "[!] $_" }) -join "`r`n" })

----------------------------------------
RECOMMENDED NEXT STEPS
----------------------------------------
1. Start with 27_Correlation_Report.txt - it ties suspicious processes to their parent, network activity, and persistence in one view.
2. Review 26_IOC_Extraction.txt - check every IP/domain/hash against threat intel (VirusTotal / AbuseIPDB / your TIP).
3. Review 07_Suspicious_Processes.txt and 25_Suspicious_File_Hashes.txt - investigate unsigned binaries or LOLBins with encoded commands.
4. Review 09_Hidden_Scheduled_Tasks.txt, 11_Persistence.txt, and 22_Registry_Deep_Dive.txt for unauthorized persistence.
5. Review 24_Anti_Forensics_Indicators.txt - cleared logs or disabled AV/firewall are high-confidence signs of active tampering.
6. Review 13_Logon_Events.txt for brute-force or unusual RDP activity.
7. If a baseline exists, re-run with -CompareBaseline and check 28_Baseline_Diff.txt for anything new.
8. Do NOT kill processes or delete files based on this report alone - preserve evidence, escalate per your IR playbook.

Files generated in this folder:
$( (Get-ChildItem $OutputRoot -Filter *.txt | Sort-Object Name | Select-Object -ExpandProperty Name) -join "`r`n" )
"@ | Out-File -FilePath $summaryPath -Encoding UTF8

Write-Host "`n=== Triage complete ===" -ForegroundColor Green
Write-Host "Risk Level: $riskLevel  |  Indicators flagged: $($Alerts.Count)"
Write-Host "All files saved to: $OutputRoot" -ForegroundColor Cyan
Invoke-Item $OutputRoot
