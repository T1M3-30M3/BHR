# =============================
# ADVANCED WINDOWS LOG ANALYSIS
# CLEAN / FIXED VERSION
# =============================

# Requires: Run PowerShell as Administrator (Security log needs elevated rights)

$OutputFolder = "C:\EventLogs"
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Host "Starting log analysis..."

function Get-ParsedLogonEvents {
    param(
        [Parameter(Mandatory)] [int]$EventId,
        [int]$MaxEvents = 5000
    )

    try {
        $events = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=$EventId} -MaxEvents $MaxEvents -ErrorAction Stop
    } catch {
        Write-Host "No events found for ID $EventId (or access denied). Skipping."
        return @()
    }

    $events | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time = $_.TimeCreated
            User = $xml.Event.EventData.Data[5].'#text'
            IP   = $xml.Event.EventData.Data[18].'#text'
            Port = $xml.Event.EventData.Data[19].'#text'
        }
    }
}

# =============================
# FAILED LOGONS (4625)
# =============================
$failedParsed = Get-ParsedLogonEvents -EventId 4625
$failedParsed | Format-Table -AutoSize | Out-File "$OutputFolder\failed_logons.txt"

# =============================
# SUCCESS LOGONS (4624)
# =============================
$successParsed = Get-ParsedLogonEvents -EventId 4624
$successParsed | Format-Table -AutoSize | Out-File "$OutputFolder\successful_logons.txt"

# =============================
# TOP ATTACKER IPS (from failed logons)
# =============================
$attackerIPs = $failedParsed |
    Where-Object { $_.IP -and $_.IP -ne "-" } |
    Group-Object IP |
    Sort-Object Count -Descending

$attackerIPs | Format-Table Name, Count | Out-File "$OutputFolder\top_attackers.txt"

# =============================
# BRUTE FORCE DETECTION (>10 failed attempts from same IP)
# =============================
$bruteforce = $attackerIPs | Where-Object { $_.Count -gt 10 }
$bruteforce | Format-Table Name, Count | Out-File "$OutputFolder\bruteforce.txt"

# =============================
# RDP LOGINS (Logon Type 10)
# =============================
try {
    $rdpRaw = Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624} -ErrorAction Stop |
        Where-Object { $_.Message -match "Logon Type:\s+10" }
} catch {
    Write-Host "No RDP (4624) events found or access denied. Skipping."
    $rdpRaw = @()
}

$rdpParsed = $rdpRaw | ForEach-Object {
    $xml = [xml]$_.ToXml()
    [PSCustomObject]@{
        Time = $_.TimeCreated
        User = $xml.Event.EventData.Data[5].'#text'
        IP   = $xml.Event.EventData.Data[18].'#text'
    }
}

$rdpParsed | Format-Table -AutoSize | Out-File "$OutputFolder\rdp_logins.txt"

# =============================
# ALL IP ACTIVITY (failed + success combined)
# =============================
$allIPs = $failedParsed + $successParsed

$allIPs |
    Where-Object { $_.IP -and $_.IP -ne "-" } |
    Group-Object IP |
    Sort-Object Count -Descending |
    Format-Table Name, Count |
    Out-File "$OutputFolder\all_ips.txt"

Write-Host "DONE! Check folder: $OutputFolder"
