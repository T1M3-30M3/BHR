﻿<#
.SYNOPSIS
    Windows SOC / DFIR host triage analyzer. Read-only. No exploitation, no
    remediation, no configuration changes.

.DESCRIPTION
    Performs host-based detection and evidence collection across processes,
    network connections, persistence mechanisms, authentication activity,
    PowerShell abuse, LOLBin usage, and security-control tampering. Produces
    console, JSON, CSV, and HTML SOC reports with a transparent risk score
    and MITRE ATT&CK mapping.

    This tool is a TRIAGE aid, not an antivirus replacement. It does not
    delete files, stop processes, modify the registry, disable security
    tools, or scan the network beyond the local host.

.PARAMETER Days
    How many days back to pull event log data. Default 7.

.PARAMETER OutputPath
    Folder to write reports to. Default C:\SOC\Reports.

.PARAMETER IOCPath
    Folder containing optional IOC files: ioc_ips.txt, ioc_domains.txt,
    ioc_hashes.txt, ioc_paths.txt, ioc_processes.txt (one value per line).

.PARAMETER IncludeFileHash
    Compute SHA256 hashes for suspicious/recent files. Slower.

.PARAMETER IncludeNetwork
    Include live network connection enumeration. Default on; use
    -IncludeNetwork:$false to skip on slow/loaded hosts.

.PARAMETER IncludeEventLogs
    Include Windows Event Log analysis. Default on.

.PARAMETER Quiet
    Suppress console progress output (reports are still written).

.EXAMPLE
    .\Windows-SOC-Analyzer.ps1 -Days 7 -OutputPath C:\SOC\Reports

.EXAMPLE
    .\Windows-SOC-Analyzer.ps1 -Days 30 -IOCPath C:\SOC\IOCs -IncludeFileHash -Verbose
#>

[CmdletBinding()]
param(
    [int]$Days = 7,
    [string]$OutputPath = "C:\SOC\Reports",
    [string]$IOCPath = $null,
    [switch]$IncludeFileHash,
    [bool]$IncludeNetwork = $true,
    [bool]$IncludeEventLogs = $true,
    [switch]$Quiet
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ============================================================
# GLOBAL STATE
# ============================================================
$Script:Findings      = New-Object System.Collections.Generic.List[object]
$Script:ErrorLog       = New-Object System.Collections.Generic.List[object]
$Script:Timeline       = New-Object System.Collections.Generic.List[object]
$Script:FindingCounter = 0
$Script:StartTimestamp = Get-Date
$Script:Hostname       = $env:COMPUTERNAME
$Script:SinceDate      = (Get-Date).AddDays(-1 * $Days)

# Allowlists - extend these for your environment before running in production.
$Script:TrustedProcessPaths = @(
    "$env:WINDIR\System32",
    "$env:WINDIR\SysWOW64",
    "$env:ProgramFiles",
    "${env:ProgramFiles(x86)}"
)
$Script:TrustedPublishers = @(
    "Microsoft Corporation",
    "Microsoft Windows"
)
$Script:KnownAdminAccounts = @("Administrator")
$Script:InternalIPRanges = @("10.", "192.168.", "172.16.", "172.17.", "172.18.",
    "172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
    "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.", "127.")

# LOLBins to watch - presence alone is not scored; command-line context is.
$Script:LOLBins = @(
    "powershell.exe","pwsh.exe","cmd.exe","wscript.exe","cscript.exe","mshta.exe",
    "rundll32.exe","regsvr32.exe","certutil.exe","bitsadmin.exe","msiexec.exe",
    "installutil.exe","reg.exe","schtasks.exe","sc.exe","wevtutil.exe","net.exe",
    "net1.exe","netsh.exe","wmic.exe","csc.exe","msbuild.exe","regasm.exe"
)

$Script:SuspiciousCommandPatterns = @(
    '-enc(odedcommand)?\s',
    '-e\s+[A-Za-z0-9+/=]{20,}',
    'FromBase64String',
    'Invoke-Expression|IEX\s',
    'DownloadString|DownloadFile',
    'Net\.WebClient',
    'Invoke-WebRequest|iwr\s',
    'Start-BitsTransfer',
    '\[Reflection\.Assembly\]',
    'amsiutils|AmsiScanBuffer|amsiInitFailed',
    '-ExecutionPolicy\s+Bypass',
    '-NoProfile.*-NonInteractive.*-WindowStyle\s+Hidden',
    '-w\s+hidden',
    '-nop\s',
    'FromBase64|ToBase64',
    'IEX\s*\(',
    'Invoke-Mimikatz|mimikatz',
    'Add-MpPreference.*-Exclusion',
    'Set-MpPreference.*Disable',
    'vssadmin.*delete.*shadows',
    'wevtutil.*cl\s',
    'Clear-EventLog|wevtutil\s+cl'
)

$Script:SuspiciousParentChild = @(
    @{ Parent = 'winword.exe';   Child = 'powershell.exe' }
    @{ Parent = 'winword.exe';   Child = 'cmd.exe' }
    @{ Parent = 'winword.exe';   Child = 'mshta.exe' }
    @{ Parent = 'winword.exe';   Child = 'rundll32.exe' }
    @{ Parent = 'excel.exe';     Child = 'powershell.exe' }
    @{ Parent = 'excel.exe';     Child = 'cmd.exe' }
    @{ Parent = 'excel.exe';     Child = 'mshta.exe' }
    @{ Parent = 'outlook.exe';   Child = 'powershell.exe' }
    @{ Parent = 'outlook.exe';   Child = 'cmd.exe' }
    @{ Parent = 'chrome.exe';    Child = 'powershell.exe' }
    @{ Parent = 'msedge.exe';    Child = 'powershell.exe' }
    @{ Parent = 'firefox.exe';   Child = 'powershell.exe' }
    @{ Parent = 'powershell.exe';Child = 'certutil.exe' }
    @{ Parent = 'powershell.exe';Child = 'regsvr32.exe' }
    @{ Parent = 'wmiprvse.exe';  Child = 'powershell.exe' }
    @{ Parent = 'wmiprvse.exe';  Child = 'cmd.exe' }
    @{ Parent = 'svchost.exe';   Child = 'powershell.exe' }
    @{ Parent = 'svchost.exe';   Child = 'cmd.exe' }
    @{ Parent = 'services.exe';  Child = 'cmd.exe' }
)

$Script:MitreMap = @{
    'EncodedPowerShell'   = 'T1059.001 - PowerShell (encoded/obfuscated execution)'
    'SuspiciousParentChild' = 'T1059 - Command and Scripting Interpreter (suspicious lineage)'
    'LOLBin'              = 'T1218 - System Binary Proxy Execution'
    'ScheduledTaskPersist'= 'T1053.005 - Scheduled Task/Job'
    'RegistryRunKey'      = 'T1547.001 - Registry Run Keys / Startup Folder'
    'ServicePersist'      = 'T1543.003 - Windows Service'
    'WMIPersist'          = 'T1546.003 - WMI Event Subscription'
    'BruteForce'          = 'T1110 - Brute Force'
    'NewAdminAccount'     = 'T1136 / T1078 - Account Creation / Valid Accounts'
    'LogCleared'          = 'T1070.001 - Clear Windows Event Logs'
    'DefenderTamper'      = 'T1562.001 - Impair Defenses (Disable/Modify Tools)'
    'RDPActivity'         = 'T1021.001 - Remote Desktop Protocol'
    'C2Network'           = 'T1105 / T1071 - Ingress Tool Transfer / C2 Channel'
    'CredentialAccess'    = 'T1003 - OS Credential Dumping (indicator only)'
    'PrivilegeUse'        = 'T1078.003 - Valid Accounts: Local Accounts'
}

# ============================================================
# CORE HELPERS
# ============================================================

function Write-Status {
    param([string]$Message, [string]$Level = "INFO")
    if ($Quiet) { return }
    $color = switch ($Level) {
        "WARN" { "Yellow" }; "ERROR" { "Red" }; "GOOD" { "Green" }; default { "Cyan" }
    }
    Write-Host "[$Level] $Message" -ForegroundColor $color
}

function Write-ModuleError {
    param([string]$Module, [string]$Message)
    $Script:ErrorLog.Add([PSCustomObject]@{
        Timestamp = Get-Date
        Module    = $Module
        Error     = $Message
    })
    Write-Status "Module '$Module' error: $Message" "WARN"
}

function New-Finding {
    param(
        [ValidateSet("Informational","Low","Medium","High","Critical")] [string]$Severity,
        [string]$Category,
        [string]$Title,
        [string]$Description,
        [string]$Evidence     = "",
        [Nullable[datetime]]$Timestamp = $null,
        [string]$User         = "",
        [string]$Process      = "",
        [string]$ProcessId    = "",
        [string]$ParentProcess= "",
        [string]$CommandLine  = "",
        [string]$FilePath     = "",
        [string]$Hash         = "",
        [string]$RemoteIP     = "",
        [string]$EventId      = "",
        [string]$MitreTechnique = "",
        [ValidateSet("IOC Match","Behavioral Detection","Heuristic Detection","Informational Finding")]
        [string]$DetectionType = "Heuristic Detection",
        [ValidateSet("Low","Medium","High")] [string]$Confidence = "Medium",
        [string]$RecommendedInvestigation = ""
    )
    $Script:FindingCounter++
    $resolvedTimestamp = Get-Date
    if ($Timestamp) { $resolvedTimestamp = $Timestamp }
    $finding = [PSCustomObject]@{
        FindingId       = "F-{0:D4}" -f $Script:FindingCounter
        Severity        = $Severity
        Category        = $Category
        Title           = $Title
        Description     = $Description
        Evidence        = $Evidence
        Timestamp       = $resolvedTimestamp
        Host            = $Script:Hostname
        User            = $User
        Process         = $Process
        PID             = $ProcessId
        ParentProcess   = $ParentProcess
        CommandLine     = $CommandLine
        FilePath        = $FilePath
        Hash            = $Hash
        RemoteIP        = $RemoteIP
        EventId         = $EventId
        MitreTechnique  = $MitreTechnique
        DetectionType   = $DetectionType
        Confidence      = $Confidence
        RecommendedInvestigation = $RecommendedInvestigation
    }
    $Script:Findings.Add($finding)
    $Script:Timeline.Add([PSCustomObject]@{
        Timestamp = $finding.Timestamp
        Category  = $Category
        Title     = $Title
        Severity  = $Severity
    })
    return $finding
}

function Test-IsTrustedPath {
    param([string]$Path)
    if (-not $Path) { return $false }
    foreach ($trusted in $Script:TrustedProcessPaths) {
        if ($trusted -and $Path -like "$trusted*") { return $true }
    }
    return $false
}

function Test-IsInternalIP {
    param([string]$IP)
    if (-not $IP) { return $false }
    foreach ($range in $Script:InternalIPRanges) {
        if ($IP.StartsWith($range)) { return $true }
    }
    return $false
}

function Invoke-SafeEventQuery {
    <# Wraps Get-WinEvent so a missing log / zero matches / access-denied
       never terminates the run. Always returns an array (possibly empty). #>
    param([hashtable]$Filter, [int]$MaxEvents = 5000, [string]$ModuleName = "EventQuery")
    try {
        $Filter['StartTime'] = $Script:SinceDate
        return @(Get-WinEvent -FilterHashtable $Filter -MaxEvents $MaxEvents -ErrorAction Stop)
    } catch [Exception] {
        if ($_.Exception.Message -match "No events were found") {
            return @()
        }
        Write-ModuleError -Module $ModuleName -Message $_.Exception.Message
        return @()
    }
}

function Get-EventXmlField {
    param($XmlEvent, [string]$Name, [int]$FallbackIndex = -1)
    try {
        $data = @($XmlEvent.Event.EventData.Data)
        if (-not $data -or $data.Count -eq 0) { return $null }
        $match = $data | Where-Object { $_.Name -eq $Name }
        if ($match) {
            $match = @($match)
            return $match[0].'#text'
        }
        if ($FallbackIndex -ge 0 -and $data.Count -gt $FallbackIndex) {
            return $data[$FallbackIndex].'#text'
        }
    } catch { }
    return $null
}

# ============================================================
# 0. PRIVILEGE / ENVIRONMENT CHECK
# ============================================================

function Test-AdminPrivileges {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-SystemInformation {
    try {
        $os  = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $cs  = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        [PSCustomObject]@{
            Hostname        = $Script:Hostname
            OS              = $os.Caption
            Version         = $os.Version
            BuildNumber     = $os.BuildNumber
            Architecture    = $os.OSArchitecture
            LastBoot        = $os.LastBootUpTime
            Manufacturer    = $cs.Manufacturer
            Model           = $cs.Model
            Domain          = $cs.Domain
            PSVersion       = $PSVersionTable.PSVersion.ToString()
            AnalysisTime    = Get-Date
        }
    } catch {
        Write-ModuleError -Module "Get-SystemInformation" -Message $_.Exception.Message
        [PSCustomObject]@{ Hostname = $Script:Hostname; OS = "Unknown"; AnalysisTime = Get-Date }
    }
}

# ============================================================
# 1. PROCESS ANALYSIS
# ============================================================

function Get-RunningProcesses {
    try {
        $procs = Get-CimInstance Win32_Process -ErrorAction Stop
        $procMap = @{}
        foreach ($p in $procs) { $procMap[$p.ProcessId] = $p }

        $procs | ForEach-Object {
            $parent = $procMap[$_.ParentProcessId]
            $exePath = $_.ExecutablePath
            $sig = $null
            if ($exePath -and (Test-Path $exePath -ErrorAction SilentlyContinue)) {
                try { $sig = Get-AuthenticodeSignature -FilePath $exePath -ErrorAction Stop } catch { }
            }
            $hash = $null
            if ($IncludeFileHash -and $exePath -and (Test-Path $exePath -ErrorAction SilentlyContinue)) {
                try { $hash = (Get-FileHash -Path $exePath -Algorithm SHA256 -ErrorAction Stop).Hash } catch { }
            }
            $ownerName = "Unknown"
            try { $ownerName = (Invoke-CimMethod -InputObject $_ -MethodName GetOwner -ErrorAction Stop).User } catch { }

            $parentName = "Unknown"
            if ($parent) { $parentName = $parent.Name }

            $sigStatus = "NotChecked"
            if ($sig) { $sigStatus = $sig.Status }

            $publisherName = $null
            if ($sig -and $sig.SignerCertificate) { $publisherName = $sig.SignerCertificate.Subject }

            [PSCustomObject]@{
                ProcessName   = $_.Name
                ProcessId     = $_.ProcessId
                ParentProcessId = $_.ParentProcessId
                ParentName    = $parentName
                CommandLine   = $_.CommandLine
                ExecutablePath= $exePath
                Owner         = $ownerName
                StartTime     = $_.CreationDate
                SignatureStatus = $sigStatus
                Publisher     = $publisherName
                SHA256        = $hash
                IsTrustedPath = Test-IsTrustedPath -Path $exePath
            }
        }
    } catch {
        Write-ModuleError -Module "Get-RunningProcesses" -Message $_.Exception.Message
        @()
    }
}

function Get-SuspiciousProcesses {
    param([array]$Processes)

    $suspicious = New-Object System.Collections.Generic.List[object]

    foreach ($proc in $Processes) {
        $reasons = New-Object System.Collections.Generic.List[string]
        $severity = "Informational"
        $mitre = $null

        # Parent-child lineage check
        foreach ($pair in $Script:SuspiciousParentChild) {
            if ($proc.ParentName -ieq $pair.Parent -and $proc.ProcessName -ieq $pair.Child) {
                $reasons.Add("Suspicious lineage: $($pair.Parent) -> $($pair.Child)")
                $severity = "High"
                $mitre = $Script:MitreMap['SuspiciousParentChild']
            }
        }

        # LOLBin command-line inspection
        if ($Script:LOLBins -contains $proc.ProcessName.ToLower() -and $proc.CommandLine) {
            foreach ($pattern in $Script:SuspiciousCommandPatterns) {
                if ($proc.CommandLine -match $pattern) {
                    $reasons.Add("Command line matches suspicious pattern: $pattern")
                    if ($severity -ne "High") { $severity = "Medium" }
                    if (-not $mitre) { $mitre = $Script:MitreMap['EncodedPowerShell'] }
                }
            }
        }

        # Unsigned binary running from a non-trusted, user-writable-ish path
        if (-not $proc.IsTrustedPath -and $proc.SignatureStatus -eq "NotSigned" -and $proc.ExecutablePath) {
            $reasons.Add("Unsigned executable running from non-standard path: $($proc.ExecutablePath)")
            if ($severity -eq "Informational") { $severity = "Low" }
        }

        if ($reasons.Count -gt 0) {
            $suspicious.Add($proc)
            New-Finding -Severity $severity -Category "Suspicious Process" `
                -Title "$($proc.ProcessName) (PID $($proc.ProcessId)) flagged" `
                -Description ($reasons -join "; ") `
                -Evidence $proc.CommandLine `
                -Process $proc.ProcessName -ProcessId $proc.ProcessId `
                -ParentProcess $proc.ParentName -CommandLine $proc.CommandLine `
                -FilePath $proc.ExecutablePath -Hash $proc.SHA256 `
                -MitreTechnique $mitre -DetectionType "Behavioral Detection" `
                -Confidence $(if ($severity -eq "High") { "High" } else { "Medium" }) `
                -RecommendedInvestigation "Review command line, parent lineage, and binary signature/hash against threat intel."
        }
    }
    return $suspicious
}

# ============================================================
# 2. NETWORK ANALYSIS
# ============================================================

function Get-NetworkConnections {
    try {
        $conns = Get-NetTCPConnection -ErrorAction Stop
        $procCache = @{}
        $conns | ForEach-Object {
            $pid_ = $_.OwningProcess
            if (-not $procCache.ContainsKey($pid_)) {
                try { $procCache[$pid_] = (Get-Process -Id $pid_ -ErrorAction Stop) } catch { $procCache[$pid_] = $null }
            }
            $proc = $procCache[$pid_]
            $connProcName = "Unknown"
            $connExePath  = $null
            if ($proc) {
                $connProcName = $proc.ProcessName
                try { $connExePath = $proc.Path } catch { }
            }
            [PSCustomObject]@{
                LocalAddress  = $_.LocalAddress
                LocalPort     = $_.LocalPort
                RemoteAddress = $_.RemoteAddress
                RemotePort    = $_.RemotePort
                State         = $_.State
                ProcessId     = $pid_
                ProcessName   = $connProcName
                ExecutablePath= $connExePath
            }
        }
    } catch {
        Write-ModuleError -Module "Get-NetworkConnections" -Message $_.Exception.Message
        @()
    }
}

function Get-SuspiciousNetworkConnections {
    param([array]$Connections, [array]$IOCIps = @())

    $suspicious = New-Object System.Collections.Generic.List[object]
    $scriptHosts = @("powershell.exe","pwsh.exe","wscript.exe","cscript.exe","mshta.exe")

    foreach ($c in $Connections) {
        if ($c.State -ne "Established") { continue }
        if (-not $c.RemoteAddress -or $c.RemoteAddress -eq "::1" -or $c.RemoteAddress -eq "0.0.0.0") { continue }

        $isInternal = Test-IsInternalIP -IP $c.RemoteAddress
        $iocHit = $IOCIps -contains $c.RemoteAddress

        if ($iocHit) {
            $suspicious.Add($c)
            New-Finding -Severity "Critical" -Category "Network" `
                -Title "Connection to known-bad IP $($c.RemoteAddress)" `
                -Description "Process $($c.ProcessName) (PID $($c.ProcessId)) has an established connection to an IP present in the supplied IOC list." `
                -RemoteIP $c.RemoteAddress -Process $c.ProcessName -ProcessId $c.ProcessId `
                -MitreTechnique $Script:MitreMap['C2Network'] -DetectionType "IOC Match" -Confidence "High" `
                -RecommendedInvestigation "Isolate host if confirmed; capture memory and pcap; review process ancestry."
            continue
        }

        if (-not $isInternal -and $scriptHosts -contains $c.ProcessName.ToLower()) {
            $suspicious.Add($c)
            New-Finding -Severity "High" -Category "Network" `
                -Title "Script interpreter making external connection" `
                -Description "$($c.ProcessName) (PID $($c.ProcessId)) has an outbound connection to external IP $($c.RemoteAddress):$($c.RemotePort)." `
                -RemoteIP $c.RemoteAddress -Process $c.ProcessName -ProcessId $c.ProcessId `
                -MitreTechnique $Script:MitreMap['C2Network'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                -RecommendedInvestigation "Correlate with process command line and parent process; check DNS/proxy logs for the destination."
        }
    }
    return $suspicious
}

# ============================================================
# 3. PERSISTENCE ANALYSIS
# ============================================================

function Get-RegistryPersistence {
    $keys = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon",
        "HKLM:\System\CurrentControlSet\Control\Session Manager"
    )
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($key in $keys) {
        try {
            if (-not (Test-Path $key)) { continue }
            $props = Get-ItemProperty -Path $key -ErrorAction Stop
            $props.PSObject.Properties |
                Where-Object { $_.Name -notmatch '^PS(Path|ParentPath|ChildName|Provider)$' } |
                ForEach-Object {
                    $entry = [PSCustomObject]@{
                        Key   = $key
                        Name  = $_.Name
                        Value = $_.Value
                    }
                    $results.Add($entry)
                    if (-not (Test-IsTrustedPath -Path ($_.Value -as [string]))) {
                        New-Finding -Severity "Medium" -Category "Persistence" `
                            -Title "Registry autorun entry: $($_.Name)" `
                            -Description "Autorun value in $key points to a non-standard location." `
                            -Evidence "$($_.Name) = $($_.Value)" `
                            -MitreTechnique $Script:MitreMap['RegistryRunKey'] -DetectionType "Heuristic Detection" `
                            -Confidence "Low" `
                            -RecommendedInvestigation "Verify the target binary is expected; check signature and install history."
                    }
                }
        } catch {
            Write-ModuleError -Module "Get-RegistryPersistence" -Message "$key : $($_.Exception.Message)"
        }
    }
    return $results
}

function Get-ScheduledTasksAnalysis {
    try {
        $tasks = Get-ScheduledTask -ErrorAction Stop
        $results = @($tasks | ForEach-Object {
            $actionParts = @($_.Actions | ForEach-Object {
                $exe = $null; $args = $null
                if ($_.PSObject.Properties.Match('Execute').Count -gt 0) { $exe = $_.Execute }
                if ($_.PSObject.Properties.Match('Arguments').Count -gt 0) { $args = $_.Arguments }
                "$exe $args".Trim()
            })
            $actions = $actionParts -join " | "
            $info = try { Get-ScheduledTaskInfo -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction Stop } catch { $null }
            $lastRun = $null
            if ($info) { $lastRun = $info.LastRunTime }
            [PSCustomObject]@{
                TaskName   = $_.TaskName
                TaskPath   = $_.TaskPath
                Author     = $_.Author
                State      = $_.State
                Actions    = $actions
                RunAsUser  = $_.Principal.UserId
                LastRunTime= $lastRun
            }
        })
        foreach ($t in $results) {
            $suspiciousLocation = $t.TaskPath -notmatch '^\\Microsoft\\'
            $suspiciousAction = $false
            foreach ($pattern in $Script:SuspiciousCommandPatterns) {
                if ($t.Actions -match $pattern) { $suspiciousAction = $true; break }
            }
            if ($suspiciousAction -or ($suspiciousLocation -and $t.Actions -match '(powershell|cmd|wscript|mshta)')) {
                New-Finding -Severity $(if ($suspiciousAction) { "High" } else { "Medium" }) -Category "Persistence" `
                    -Title "Suspicious scheduled task: $($t.TaskName)" `
                    -Description "Task path $($t.TaskPath) runs: $($t.Actions)" `
                    -Evidence $t.Actions -User $t.RunAsUser `
                    -MitreTechnique $Script:MitreMap['ScheduledTaskPersist'] -DetectionType "Heuristic Detection" `
                    -Confidence "Medium" `
                    -RecommendedInvestigation "Confirm task creator/purpose; check 4698 event for creation source."
            }
        }
        return $results
    } catch {
        Write-ModuleError -Module "Get-ScheduledTasksAnalysis" -Message $_.Exception.Message
        return @()
    }
}

function Get-SuspiciousServices {
    try {
        $services = Get-CimInstance Win32_Service -ErrorAction Stop
        $results = @($services | ForEach-Object {
            [PSCustomObject]@{
                Name       = $_.Name
                DisplayName= $_.DisplayName
                PathName   = $_.PathName
                StartMode  = $_.StartMode
                State      = $_.State
                StartName  = $_.StartName
            }
        })
        foreach ($svc in $results) {
            if (-not $svc.PathName) { continue }
            $exePath = ($svc.PathName -replace '^"([^"]+)".*$', '$1')
            $userWritableHint = $exePath -match '\\(Users|Temp|AppData|ProgramData)\\'
            $unsigned = $false
            if (Test-Path $exePath -ErrorAction SilentlyContinue) {
                try {
                    $sig = Get-AuthenticodeSignature -FilePath $exePath -ErrorAction Stop
                    $unsigned = ($sig.Status -ne "Valid")
                } catch { }
            }
            if ($userWritableHint -or ($unsigned -and -not (Test-IsTrustedPath -Path $exePath))) {
                New-Finding -Severity "High" -Category "Persistence" `
                    -Title "Suspicious service: $($svc.Name)" `
                    -Description "Service '$($svc.DisplayName)' runs from $exePath (writable-path hint: $userWritableHint, unsigned: $unsigned)." `
                    -Evidence $svc.PathName -FilePath $exePath `
                    -MitreTechnique $Script:MitreMap['ServicePersist'] -DetectionType "Heuristic Detection" `
                    -Confidence "Medium" `
                    -RecommendedInvestigation "Check event ID 4697/7045 for install time and installer identity."
            }
        }
        return $results
    } catch {
        Write-ModuleError -Module "Get-SuspiciousServices" -Message $_.Exception.Message
        return @()
    }
}

function Get-WMIPersistence {
    try {
        $consumers = Get-CimInstance -Namespace root\subscription -ClassName __EventConsumer -ErrorAction Stop
        $filters   = Get-CimInstance -Namespace root\subscription -ClassName __EventFilter -ErrorAction Stop
        $bindings  = Get-CimInstance -Namespace root\subscription -ClassName __FilterToConsumerBinding -ErrorAction Stop

        foreach ($c in $consumers) {
            New-Finding -Severity "High" -Category "Persistence" `
                -Title "WMI permanent event consumer present: $($c.Name)" `
                -Description "A WMI event consumer exists on this host. Permanent WMI subscriptions are a known persistence technique and should be verified as legitimate (e.g. management tooling)." `
                -Evidence ($c | Out-String) `
                -MitreTechnique $Script:MitreMap['WMIPersist'] -DetectionType "Heuristic Detection" -Confidence "Low" `
                -RecommendedInvestigation "Correlate consumer with filter/binding; confirm origin and business justification."
        }
        return [PSCustomObject]@{ Consumers = $consumers; Filters = $filters; Bindings = $bindings }
    } catch {
        Write-ModuleError -Module "Get-WMIPersistence" -Message $_.Exception.Message
        return [PSCustomObject]@{ Consumers = @(); Filters = @(); Bindings = @() }
    }
}

# ============================================================
# 4. ACCOUNT & AUTHENTICATION ANALYSIS
# ============================================================

function Get-UserAccounts {
    try {
        Get-LocalUser -ErrorAction Stop | Select-Object Name, Enabled, LastLogon, PasswordRequired, PasswordExpires, Description
    } catch {
        Write-ModuleError -Module "Get-UserAccounts" -Message $_.Exception.Message
        @()
    }
}

function Get-PrivilegedAccounts {
    try {
        $admins = Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop
        foreach ($a in $admins) {
            if ($Script:KnownAdminAccounts -notcontains ($a.Name -split '\\')[-1]) {
                New-Finding -Severity "Low" -Category "Account" `
                    -Title "Local administrator: $($a.Name)" `
                    -Description "Account is a member of the local Administrators group and is not in the known-admin allowlist. Verify this is expected." `
                    -User $a.Name -DetectionType "Informational Finding" -Confidence "Low" `
                    -RecommendedInvestigation "Confirm business justification for admin membership; check 4732 event for when it was added."
            }
        }
        return $admins
    } catch {
        Write-ModuleError -Module "Get-PrivilegedAccounts" -Message $_.Exception.Message
        return @()
    }
}

function Get-SecurityEvents {
    if (-not $IncludeEventLogs) { return $null }

    $result = [PSCustomObject]@{
        Logons          = @()
        FailedLogons    = @()
        AccountChanges  = @()
        Lockouts        = @()
        LogClearing     = @()
        PrivilegeUse    = @()
    }

    # 4624 successful logon
    $success = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=4624} -ModuleName "SecurityEvents-4624"
    $result.Logons = @($success | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time     = $_.TimeCreated
            User     = Get-EventXmlField $xml "TargetUserName" 5
            LogonType= Get-EventXmlField $xml "LogonType"
            IP       = Get-EventXmlField $xml "IpAddress" 18
            Port     = Get-EventXmlField $xml "IpPort" 19
        }
    })

    # 4625 failed logon
    $failed = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=4625} -ModuleName "SecurityEvents-4625"
    $result.FailedLogons = @($failed | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time = $_.TimeCreated
            User = Get-EventXmlField $xml "TargetUserName" 5
            IP   = Get-EventXmlField $xml "IpAddress" 18
            Port = Get-EventXmlField $xml "IpPort" 19
        }
    })

    # Brute-force / spray heuristic: >= 10 failures from one IP, or >=5 distinct users targeted from one IP
    $byIp = @($result.FailedLogons | Where-Object { $_.IP -and $_.IP -ne "-" } | Group-Object IP)
    foreach ($grp in $byIp) {
        if ($grp.Count -ge 10) {
            New-Finding -Severity "High" -Category "Authentication" `
                -Title "Possible brute-force from $($grp.Name)" `
                -Description "$($grp.Count) failed logon attempts (Event 4625) from IP $($grp.Name) within the analysis window." `
                -RemoteIP $grp.Name -EventId "4625" `
                -MitreTechnique $Script:MitreMap['BruteForce'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                -RecommendedInvestigation "Check for a subsequent successful logon (4624) from the same IP; consider blocking at the firewall."
        }
        $distinctUsers = @($grp.Group | Select-Object -ExpandProperty User -Unique).Count
        if ($distinctUsers -ge 5) {
            New-Finding -Severity "High" -Category "Authentication" `
                -Title "Possible password spray from $($grp.Name)" `
                -Description "IP $($grp.Name) attempted logons against $distinctUsers distinct usernames." `
                -RemoteIP $grp.Name -EventId "4625" `
                -MitreTechnique $Script:MitreMap['BruteForce'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                -RecommendedInvestigation "Cross-reference targeted usernames; check for any resulting successful authentication."
        }
    }

    # Failed-then-success from same IP within window (simple correlation)
    # @() wrap is required: a bare string is IEnumerable<char>, so foreach over an
    # un-wrapped single-IP result would iterate character-by-character instead of once.
    $successIps = @($result.Logons | Where-Object { $_.IP -and $_.IP -ne "-" } | Select-Object -ExpandProperty IP -Unique)
    foreach ($ip in $successIps) {
        $failuresFromIp = @($result.FailedLogons | Where-Object { $_.IP -eq $ip }).Count
        if ($failuresFromIp -ge 5) {
            New-Finding -Severity "Medium" -Category "Authentication" `
                -Title "Failed attempts followed by successful logon: $ip" `
                -Description "$failuresFromIp failed attempts from $ip preceded at least one successful logon (4624) from the same IP." `
                -RemoteIP $ip -DetectionType "Behavioral Detection" -Confidence "Medium" `
                -RecommendedInvestigation "High-value correlation - verify the successful logon's account and subsequent activity."
        }
    }

    # Account management: 4720 created, 4726 deleted, 4738 changed, 4732 added to group
    $acctIds = @(4720,4722,4723,4724,4725,4726,4732,4738)
    $acctEvents = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=$acctIds} -MaxEvents 2000 -ModuleName "SecurityEvents-AccountMgmt"
    $result.AccountChanges = @($acctEvents | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time    = $_.TimeCreated
            EventId = $_.Id
            Target  = Get-EventXmlField $xml "TargetUserName"
            Actor   = Get-EventXmlField $xml "SubjectUserName"
        }
    })
    foreach ($e in @($result.AccountChanges | Where-Object { $_.EventId -eq 4720 })) {
        New-Finding -Severity "Medium" -Category "Account" `
            -Title "New account created: $($e.Target)" `
            -Description "Account '$($e.Target)' was created by '$($e.Actor)'." `
            -User $e.Target -EventId "4720" -Timestamp $e.Time `
            -MitreTechnique $Script:MitreMap['NewAdminAccount'] -DetectionType "Behavioral Detection" -Confidence "Low" `
            -RecommendedInvestigation "Confirm this account creation was authorized change management."
    }
    foreach ($e in @($result.AccountChanges | Where-Object { $_.EventId -eq 4732 })) {
        New-Finding -Severity "Medium" -Category "Account" `
            -Title "Member added to privileged/local group: $($e.Target)" `
            -Description "'$($e.Target)' was added to a security-enabled local group by '$($e.Actor)'." `
            -User $e.Target -EventId "4732" -Timestamp $e.Time `
            -MitreTechnique $Script:MitreMap['PrivilegeUse'] -DetectionType "Behavioral Detection" -Confidence "Low" `
            -RecommendedInvestigation "Verify group membership change against change records."
    }

    # 4740 lockouts
    $lockEvents = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=4740} -MaxEvents 2000 -ModuleName "SecurityEvents-4740"
    $result.Lockouts = @($lockEvents | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{ Time = $_.TimeCreated; User = Get-EventXmlField $xml "TargetUserName" }
    })

    # 1102 audit log cleared - always high-signal
    $clearEvents = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=1102} -MaxEvents 100 -ModuleName "SecurityEvents-1102"
    $result.LogClearing = @($clearEvents | ForEach-Object {
        [PSCustomObject]@{ Time = $_.TimeCreated; Message = $_.Message }
    })
    foreach ($e in $result.LogClearing) {
        New-Finding -Severity "Critical" -Category "Defense Evasion" `
            -Title "Security event log was cleared" `
            -Description "Event 1102 recorded at $($e.Time) - the Security event log audit trail was cleared." `
            -EventId "1102" -Timestamp $e.Time `
            -MitreTechnique $Script:MitreMap['LogCleared'] -DetectionType "Behavioral Detection" -Confidence "High" `
            -RecommendedInvestigation "Immediately review who cleared the log (SubjectUserName in event detail) and what activity preceded it in other log sources (SIEM/forwarded logs)."
    }

    # 4672 special privileges assigned
    $privEvents = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=4672} -MaxEvents 2000 -ModuleName "SecurityEvents-4672"
    $result.PrivilegeUse = @($privEvents | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{ Time = $_.TimeCreated; User = Get-EventXmlField $xml "SubjectUserName" }
    })

    return $result
}

function Get-PowerShellEvents {
    if (-not $IncludeEventLogs) { return @() }

    $events = @()
    try {
        $events = Invoke-SafeEventQuery -Filter @{LogName='Microsoft-Windows-PowerShell/Operational'; Id=@(4103,4104)} `
            -MaxEvents 3000 -ModuleName "PowerShellEvents"
    } catch {
        Write-ModuleError -Module "Get-PowerShellEvents" -Message $_.Exception.Message
        return @()
    }

    $parsed = @($events | ForEach-Object {
        [PSCustomObject]@{
            Time    = $_.TimeCreated
            EventId = $_.Id
            Message = $_.Message
        }
    })

    foreach ($e in $parsed) {
        foreach ($pattern in $Script:SuspiciousCommandPatterns) {
            if ($e.Message -match $pattern) {
                New-Finding -Severity "High" -Category "PowerShell" `
                    -Title "Suspicious PowerShell script block (Event $($e.EventId))" `
                    -Description "Script block content matched pattern: $pattern" `
                    -Evidence ($e.Message.Substring(0, [Math]::Min(500, $e.Message.Length))) `
                    -EventId "$($e.EventId)" -Timestamp $e.Time `
                    -MitreTechnique $Script:MitreMap['EncodedPowerShell'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                    -RecommendedInvestigation "Review full script block text (4104) and correlate with 4688 process creation for the hosting powershell.exe PID."
                break
            }
        }
    }
    return $parsed
}

function Get-RDPActivity {
    if (-not $IncludeEventLogs) { return @() }
    $rdpRaw = Invoke-SafeEventQuery -Filter @{LogName='Security'; Id=4624} -ModuleName "RDPActivity" |
        Where-Object { $_.Message -match "Logon Type:\s+10" }

    $parsed = @($rdpRaw | ForEach-Object {
        $xml = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time = $_.TimeCreated
            User = Get-EventXmlField $xml "TargetUserName" 5
            IP   = Get-EventXmlField $xml "IpAddress" 18
        }
    })
    foreach ($e in $parsed) {
        if ($e.IP -and -not (Test-IsInternalIP -IP $e.IP)) {
            New-Finding -Severity "High" -Category "Remote Access" `
                -Title "RDP logon from external IP: $($e.IP)" `
                -Description "User '$($e.User)' logged on via RDP (Logon Type 10) from external IP $($e.IP)." `
                -User $e.User -RemoteIP $e.IP -Timestamp $e.Time -EventId "4624" `
                -MitreTechnique $Script:MitreMap['RDPActivity'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                -RecommendedInvestigation "Confirm this is an authorized remote-access path (VPN-terminated vs. directly internet-facing RDP)."
        }
    }
    return $parsed
}

# ============================================================
# 5. SECURITY CONTROL ANALYSIS
# ============================================================

function Get-DefenderStatus {
    try {
        $status = Get-MpComputerStatus -ErrorAction Stop
        if (-not $status.RealTimeProtectionEnabled) {
            New-Finding -Severity "Critical" -Category "Security Control" `
                -Title "Defender real-time protection is disabled" `
                -Description "RealTimeProtectionEnabled = false on this host." `
                -MitreTechnique $Script:MitreMap['DefenderTamper'] -DetectionType "Behavioral Detection" -Confidence "High" `
                -RecommendedInvestigation "Determine when/how RTP was disabled (GPO change, local admin action, malware tampering)."
        }
        if ($status.AntivirusEnabled -eq $false) {
            New-Finding -Severity "High" -Category "Security Control" `
                -Title "Antivirus reported disabled" `
                -Description "AntivirusEnabled = false." `
                -MitreTechnique $Script:MitreMap['DefenderTamper'] -DetectionType "Behavioral Detection" -Confidence "High" `
                -RecommendedInvestigation "Check Defender operational log for tamper-related events."
        }
        return $status
    } catch {
        Write-ModuleError -Module "Get-DefenderStatus" -Message $_.Exception.Message
        return $null
    }
}

function Get-DefenderEvents {
    if (-not $IncludeEventLogs) { return @() }
    $events = Invoke-SafeEventQuery -Filter @{LogName='Microsoft-Windows-Windows Defender/Operational'; Id=@(1006,1116,1117,5001,5010,5012)} `
        -MaxEvents 2000 -ModuleName "DefenderEvents"
    $parsed = @($events | ForEach-Object {
        [PSCustomObject]@{ Time = $_.TimeCreated; EventId = $_.Id; Message = $_.Message }
    })
    foreach ($e in $parsed) {
        $sev = switch ($e.EventId) {
            {$_ -in 1006,1116,1117} { "High" }      # detection / malware found
            {$_ -in 5001,5010,5012} { "Critical" }  # RTP disabled / scanning disabled / tamper
            default { "Medium" }
        }
        New-Finding -Severity $sev -Category "Defender" `
            -Title "Defender event $($e.EventId)" `
            -Description $e.Message.Substring(0, [Math]::Min(300, $e.Message.Length)) `
            -EventId "$($e.EventId)" -Timestamp $e.Time `
            -MitreTechnique $Script:MitreMap['DefenderTamper'] -DetectionType "Behavioral Detection" -Confidence "High" `
            -RecommendedInvestigation "Review full Defender event detail and any correlated process activity."
    }
    return $parsed
}

function Get-FirewallStatus {
    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            if (-not $p.Enabled) {
                New-Finding -Severity "Medium" -Category "Security Control" `
                    -Title "Firewall profile disabled: $($p.Name)" `
                    -Description "The $($p.Name) firewall profile is disabled." `
                    -MitreTechnique $Script:MitreMap['DefenderTamper'] -DetectionType "Behavioral Detection" -Confidence "Medium" `
                    -RecommendedInvestigation "Confirm whether disabled intentionally (e.g. third-party firewall in use)."
            }
        }
        return $profiles
    } catch {
        Write-ModuleError -Module "Get-FirewallStatus" -Message $_.Exception.Message
        return @()
    }
}

# ============================================================
# 6. IOC SUPPORT
# ============================================================

function Import-IOCs {
    param([string]$Path)
    $result = [PSCustomObject]@{ IPs = @(); Domains = @(); Hashes = @(); Paths = @(); Processes = @() }
    if (-not $Path -or -not (Test-Path $Path)) { return $result }

    $map = @{
        'ioc_ips.txt'       = 'IPs'
        'ioc_domains.txt'   = 'Domains'
        'ioc_hashes.txt'    = 'Hashes'
        'ioc_paths.txt'     = 'Paths'
        'ioc_processes.txt' = 'Processes'
    }
    foreach ($file in $map.Keys) {
        $full = Join-Path $Path $file
        if (Test-Path $full) {
            try {
                $lines = Get-Content $full -ErrorAction Stop | Where-Object { $_ -and $_.Trim() -ne "" -and -not $_.StartsWith('#') }
                $result.($map[$file]) = $lines
            } catch {
                Write-ModuleError -Module "Import-IOCs" -Message "$file : $($_.Exception.Message)"
            }
        }
    }
    return $result
}

# ============================================================
# 7. RISK SCORING
# ============================================================

function Get-CalculateRiskScore {
    param([array]$Findings)

    $weights = @{ Informational = 0; Low = 3; Medium = 8; High = 18; Critical = 30 }
    $score = 0
    foreach ($f in $Findings) {
        $score += $weights[$f.Severity]
    }
    $score = [Math]::Min(100, $score)

    $level = if ($score -ge 80) { "Critical" }
             elseif ($score -ge 60) { "High" }
             elseif ($score -ge 40) { "Medium" }
             elseif ($score -ge 20) { "Low" }
             else { "Informational" }

    [PSCustomObject]@{ Score = $score; Level = $level }
}

function Get-ExecutiveVerdict {
    param([int]$Score, [array]$Findings)

    $criticalCount = @($Findings | Where-Object { $_.Severity -eq "Critical" }).Count
    $highCount     = @($Findings | Where-Object { $_.Severity -eq "High" }).Count

    $verdict = if ($criticalCount -gt 0) { "CRITICAL / POTENTIAL COMPROMISE" }
               elseif ($highCount -ge 3) { "HIGH RISK" }
               elseif ($highCount -ge 1 -or $Score -ge 40) { "SUSPICIOUS" }
               elseif ($Score -ge 20) { "LOW RISK" }
               else { "CLEAN" }
    return $verdict
}

# ============================================================
# 8. REPORT GENERATION
# ============================================================

function Export-SOCReports {
    param($SysInfo, $RiskScore, $Verdict, [string]$OutPath)

    if (-not (Test-Path $OutPath)) {
        New-Item -ItemType Directory -Path $OutPath -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $base = "SOC_Report_$($Script:Hostname)_$timestamp"

    # PS 5.1-compatible verdict->color lookup (avoids the ?: ternary operator, PS7+ only)
    $verdictColorKey = "Informational"
    if ($Verdict -match "CRITICAL")       { $verdictColorKey = "Critical" }
    elseif ($Verdict -match "HIGH")       { $verdictColorKey = "High" }
    elseif ($Verdict -match "SUSPICIOUS") { $verdictColorKey = "Medium" }
    elseif ($Verdict -match "LOW")        { $verdictColorKey = "Low" }

    # JSON
    $jsonPath = Join-Path $OutPath "$base.json"
    $exportObj = [PSCustomObject]@{
        SystemInfo = $SysInfo
        RiskScore  = $RiskScore
        Verdict    = $Verdict
        Findings   = $Script:Findings
        Timeline   = ($Script:Timeline | Sort-Object Timestamp)
        Errors     = $Script:ErrorLog
    }
    $exportObj | ConvertTo-Json -Depth 6 | Out-File -FilePath $jsonPath -Encoding UTF8

    # CSV
    $csvPath = Join-Path $OutPath "SOC_Findings_$($Script:Hostname)_$timestamp.csv"
    $Script:Findings | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

    # HTML
    $htmlPath = Join-Path $OutPath "$base.html"
    $sevColor = @{ Critical="#7a0d0d"; High="#c0392b"; Medium="#d68910"; Low="#2e86c1"; Informational="#7f8c8d" }
    $findingsHtml = ($Script:Findings | Sort-Object @{Expression={
            switch ($_.Severity) {"Critical"{0}"High"{1}"Medium"{2}"Low"{3}default{4}}
        }}, Timestamp | ForEach-Object {
        $c = $sevColor[$_.Severity]
        "<tr style='border-left:6px solid $c;'>
            <td>$($_.FindingId)</td><td style='color:$c;font-weight:bold;'>$($_.Severity)</td>
            <td>$($_.Category)</td><td>$($_.Title)</td><td>$($_.Description)</td>
            <td>$($_.MitreTechnique)</td><td>$($_.DetectionType)</td><td>$($_.Confidence)</td>
            <td>$($_.Timestamp)</td>
        </tr>"
    }) -join "`n"

    $html = @"
<!DOCTYPE html>
<html><head><meta charset='utf-8'><title>SOC Report - $($Script:Hostname)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;background:#0f1115;color:#e8e8e8;margin:0;padding:24px;}
h1{color:#fff;} h2{border-bottom:1px solid #444;padding-bottom:6px;color:#ddd;}
table{border-collapse:collapse;width:100%;margin-bottom:24px;font-size:13px;}
td,th{padding:8px;border-bottom:1px solid #2a2a2a;text-align:left;vertical-align:top;}
th{background:#1b1e24;color:#fff;}
.summary{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px;}
.card{background:#1b1e24;padding:16px 24px;border-radius:8px;min-width:160px;}
.card .num{font-size:28px;font-weight:bold;}
.verdict{padding:16px;border-radius:8px;font-size:20px;font-weight:bold;margin-bottom:24px;}
</style></head><body>
<h1>Windows SOC Security Analysis Report</h1>
<p>Host: <b>$($SysInfo.Hostname)</b> | OS: $($SysInfo.OS) | Generated: $($SysInfo.AnalysisTime)</p>

<div class='verdict' style='background:$($sevColor[$verdictColorKey]);'>
Executive Verdict: $Verdict
</div>

<div class='summary'>
<div class='card'><div>Risk Score</div><div class='num'>$($RiskScore.Score)/100</div></div>
<div class='card'><div>Risk Level</div><div class='num'>$($RiskScore.Level)</div></div>
<div class='card'><div>Critical</div><div class='num'>$(@($Script:Findings | Where-Object {$_.Severity -eq 'Critical'}).Count)</div></div>
<div class='card'><div>High</div><div class='num'>$(@($Script:Findings | Where-Object {$_.Severity -eq 'High'}).Count)</div></div>
<div class='card'><div>Medium</div><div class='num'>$(@($Script:Findings | Where-Object {$_.Severity -eq 'Medium'}).Count)</div></div>
<div class='card'><div>Low</div><div class='num'>$(@($Script:Findings | Where-Object {$_.Severity -eq 'Low'}).Count)</div></div>
</div>

<h2>Findings</h2>
<table>
<tr><th>ID</th><th>Severity</th><th>Category</th><th>Title</th><th>Description</th><th>MITRE</th><th>Detection Type</th><th>Confidence</th><th>Timestamp</th></tr>
$findingsHtml
</table>

<h2>Module Errors</h2>
<table><tr><th>Time</th><th>Module</th><th>Error</th></tr>
$(($Script:ErrorLog | ForEach-Object { "<tr><td>$($_.Timestamp)</td><td>$($_.Module)</td><td>$($_.Error)</td></tr>" }) -join "`n")
</table>

</body></html>
"@
    $html | Out-File -FilePath $htmlPath -Encoding UTF8

    # Error log
    $errPath = Join-Path $OutPath "SOC_Analyzer_Errors_$($Script:Hostname)_$timestamp.log"
    $Script:ErrorLog | ForEach-Object { "$($_.Timestamp) [$($_.Module)] $($_.Error)" } | Out-File -FilePath $errPath -Encoding UTF8

    return [PSCustomObject]@{ Json = $jsonPath; Csv = $csvPath; Html = $htmlPath; ErrorLog = $errPath }
}

function Write-ConsoleSummary {
    param($SysInfo, $RiskScore, $Verdict)

    if ($Quiet) { return }

    Write-Host ""
    Write-Host "========================================" -ForegroundColor DarkCyan
    Write-Host " WINDOWS SOC SECURITY ANALYZER" -ForegroundColor DarkCyan
    Write-Host "========================================" -ForegroundColor DarkCyan
    Write-Host "Host:            $($SysInfo.Hostname)"
    Write-Host "OS:              $($SysInfo.OS)"
    Write-Host "Analysis Time:   $($SysInfo.AnalysisTime)"
    Write-Host ""
    Write-Host "Risk Score:      $($RiskScore.Score)/100"
    Write-Host "Risk Level:      $($RiskScore.Level)"
    Write-Host "Verdict:         $Verdict" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Critical Findings: $(@($Script:Findings | Where-Object {$_.Severity -eq 'Critical'}).Count)" -ForegroundColor Red
    Write-Host "High Findings:     $(@($Script:Findings | Where-Object {$_.Severity -eq 'High'}).Count)" -ForegroundColor Red
    Write-Host "Medium Findings:   $(@($Script:Findings | Where-Object {$_.Severity -eq 'Medium'}).Count)" -ForegroundColor Yellow
    Write-Host "Low Findings:      $(@($Script:Findings | Where-Object {$_.Severity -eq 'Low'}).Count)" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Top findings:"
    $Script:Findings | Sort-Object @{Expression={switch ($_.Severity){"Critical"{0}"High"{1}"Medium"{2}"Low"{3}default{4}}}} |
        Select-Object -First 10 | ForEach-Object {
            Write-Host " [$($_.Severity)] $($_.Title)" -ForegroundColor $(switch ($_.Severity) {"Critical"{"Red"}"High"{"Red"}"Medium"{"Yellow"}default{"Gray"}})
        }
    Write-Host ""
}

# ============================================================
# MAIN
# ============================================================

function Invoke-SOCAnalysis {
    if (-not (Test-AdminPrivileges)) {
        Write-Status "Not running as Administrator - Security log and some WMI/service queries will be limited or empty." "WARN"
    }

    Write-Status "Gathering system information..."
    $sysInfo = Get-SystemInformation

    Write-Status "Loading IOCs..."
    $iocs = Import-IOCs -Path $IOCPath

    Write-Status "Enumerating processes..."
    $processes = Get-RunningProcesses
    Write-Status "Analyzing process lineage and command lines..."
    $suspiciousProcesses = Get-SuspiciousProcesses -Processes $processes

    # IOC match pass on process hashes/paths
    foreach ($p in $processes) {
        if ($p.SHA256 -and $iocs.Hashes -contains $p.SHA256) {
            New-Finding -Severity "Critical" -Category "IOC Match" `
                -Title "Process hash matches IOC list" -Description "$($p.ProcessName) (PID $($p.ProcessId)) hash matches a supplied IOC hash." `
                -Process $p.ProcessName -ProcessId $p.ProcessId -Hash $p.SHA256 -FilePath $p.ExecutablePath `
                -DetectionType "IOC Match" -Confidence "High" `
                -RecommendedInvestigation "Isolate host; this is a confirmed IOC match pending validation of the IOC source."
        }
        if ($p.ExecutablePath -and $iocs.Paths -contains $p.ExecutablePath) {
            New-Finding -Severity "High" -Category "IOC Match" `
                -Title "Process path matches IOC list" -Description "$($p.ProcessName) path matches a supplied IOC path." `
                -Process $p.ProcessName -ProcessId $p.ProcessId -FilePath $p.ExecutablePath `
                -DetectionType "IOC Match" -Confidence "Medium" `
                -RecommendedInvestigation "Validate IOC entry currency, then treat as high-priority."
        }
    }

    $connections = @()
    $suspiciousConnections = @()
    if ($IncludeNetwork) {
        Write-Status "Enumerating network connections..."
        $connections = Get-NetworkConnections
        Write-Status "Analyzing network connections..."
        $suspiciousConnections = Get-SuspiciousNetworkConnections -Connections $connections -IOCIps $iocs.IPs
    }

    Write-Status "Checking registry persistence locations..."
    $registryPersistence = Get-RegistryPersistence

    Write-Status "Analyzing scheduled tasks..."
    $scheduledTasks = Get-ScheduledTasksAnalysis

    Write-Status "Analyzing services..."
    $services = Get-SuspiciousServices

    Write-Status "Checking WMI persistence..."
    $wmi = Get-WMIPersistence

    Write-Status "Enumerating accounts..."
    $users = Get-UserAccounts
    $admins = Get-PrivilegedAccounts

    $securityEvents = $null
    $psEvents = @()
    $rdpEvents = @()
    if ($IncludeEventLogs) {
        Write-Status "Analyzing Security event log (this can take a while)..."
        $securityEvents = Get-SecurityEvents
        Write-Status "Analyzing PowerShell operational log..."
        $psEvents = Get-PowerShellEvents
        Write-Status "Analyzing RDP activity..."
        $rdpEvents = Get-RDPActivity
    }

    Write-Status "Checking Windows Defender status..."
    $defenderStatus = Get-DefenderStatus
    $defenderEvents = Get-DefenderEvents

    Write-Status "Checking firewall status..."
    $firewall = Get-FirewallStatus

    Write-Status "Calculating risk score..."
    $riskScore = Get-CalculateRiskScore -Findings $Script:Findings
    $verdict   = Get-ExecutiveVerdict -Score $riskScore.Score -Findings $Script:Findings

    Write-ConsoleSummary -SysInfo $sysInfo -RiskScore $riskScore -Verdict $verdict

    Write-Status "Writing reports to $OutputPath ..."
    $reportPaths = Export-SOCReports -SysInfo $sysInfo -RiskScore $riskScore -Verdict $verdict -OutPath $OutputPath

    Write-Status "JSON: $($reportPaths.Json)" "GOOD"
    Write-Status "CSV:  $($reportPaths.Csv)" "GOOD"
    Write-Status "HTML: $($reportPaths.Html)" "GOOD"
    if ($Script:ErrorLog.Count -gt 0) {
        Write-Status "Errors logged: $($reportPaths.ErrorLog) ($($Script:ErrorLog.Count) module warnings)" "WARN"
    }

    return [PSCustomObject]@{
        SystemInfo = $sysInfo
        RiskScore  = $riskScore
        Verdict    = $verdict
        Findings   = $Script:Findings
        Reports    = $reportPaths
    }
}

# Entry point
Invoke-SOCAnalysis | Out-Null
