# =============================
# CATEGORY-WISE LOG ANALYSIS SCRIPT
# CLEAN / FIXED VERSION
# =============================

# Requires: Run PowerShell as Administrator (Security log needs elevated rights)

$OutputFolder = "C:\CategoryLogs"
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Host "Starting categorized log analysis..."

# Generic safe field getter — avoids index-out-of-range on events with fewer fields
function Get-EventDataField {
    param($xmlEvent, [int]$Index)
    $data = $xmlEvent.Event.EventData.Data
    if ($data -and $data.Count -gt $Index) {
        return $data[$Index].'#text'
    }
    return $null
}

# Parses logon-type events (4624 / 4625) where User/IP/Port are at fixed indices
function Parse-LogonEvent {
    param($event)
    $xml = [xml]$event.ToXml()
    [PSCustomObject]@{
        Time = $event.TimeCreated
        User = Get-EventDataField $xml 5
        IP   = Get-EventDataField $xml 18
        Port = Get-EventDataField $xml 19
    }
}

# Generic parser for non-logon events — dumps all EventData as Name/Value pairs
# instead of assuming fixed indices that don't apply to that event type
function Parse-GenericEvent {
    param($event)
    $xml = [xml]$event.ToXml()
    $fields = @{}
    $xml.Event.EventData.Data | ForEach-Object {
        if ($_.Name) { $fields[$_.Name] = $_.'#text' }
    }
    [PSCustomObject]@{
        Time     = $event.TimeCreated
        EventId  = $event.Id
        Fields   = ($fields.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; '
    }
}

function Get-SafeEvents {
    param([hashtable]$Filter, [int]$MaxEvents = 5000)
    try {
        return Get-WinEvent -FilterHashtable $Filter -MaxEvents $MaxEvents -ErrorAction Stop
    } catch {
        Write-Host "No events found for filter (or access denied). Skipping."
        return @()
    }
}

# =============================
# 1. LOGON / LOGOFF (4624 success, 4625 failure)
# =============================
$successEvents = Get-SafeEvents -Filter @{LogName='Security'; Id=4624} | ForEach-Object { Parse-LogonEvent $_ }
$failedEvents  = Get-SafeEvents -Filter @{LogName='Security'; Id=4625} | ForEach-Object { Parse-LogonEvent $_ }
$logonEvents   = $successEvents + $failedEvents

$logonEvents | Format-Table -AutoSize | Out-File "$OutputFolder\logon_events.txt"

# =============================
# 2. ACCOUNT MANAGEMENT (4720 created, 4726 deleted, 4738 changed)
# =============================
$accountEvents = Get-SafeEvents -Filter @{LogName='Security'; Id=@(4720,4726,4738)} -MaxEvents 2000 |
    ForEach-Object { Parse-GenericEvent $_ }

$accountEvents | Format-Table -AutoSize | Out-File "$OutputFolder\account_management.txt"

# =============================
# 3. PRIVILEGE USE (4672)
# =============================
$privEvents = Get-SafeEvents -Filter @{LogName='Security'; Id=4672} -MaxEvents 2000 |
    ForEach-Object { Parse-GenericEvent $_ }

$privEvents | Format-Table -AutoSize | Out-File "$OutputFolder\privilege_events.txt"

# =============================
# 4. PROCESS CREATION (4688)
# =============================
$procEvents = Get-SafeEvents -Filter @{LogName='Security'; Id=4688} -MaxEvents 2000 |
    ForEach-Object { Parse-GenericEvent $_ }

$procEvents | Format-Table -AutoSize | Out-File "$OutputFolder\process_events.txt"

# =============================
# 5. ACCOUNT LOCK EVENTS (4740)
# =============================
$lockEvents = Get-SafeEvents -Filter @{LogName='Security'; Id=4740} -MaxEvents 2000 |
    ForEach-Object { Parse-GenericEvent $_ }

$lockEvents | Format-Table -AutoSize | Out-File "$OutputFolder\account_lockouts.txt"

# =============================
# 6. RDP EVENTS (LOGON TYPE 10, from 4624 successes)
# =============================
$rdpEvents = $successEvents | Where-Object {
    # Logon Type 10 = RemoteInteractive (RDP). Re-check against raw event for accuracy.
    $true
}

# More reliable: filter directly from Get-WinEvent using the Message text
$rdpRaw = Get-SafeEvents -Filter @{LogName='Security'; Id=4624} |
    Where-Object { $_.Message -match "Logon Type:\s+10" }

$rdpParsed = $rdpRaw | ForEach-Object { Parse-LogonEvent $_ }
$rdpParsed | Format-Table -AutoSize | Out-File "$OutputFolder\rdp_events.txt"

# =============================
# 7. ATTACKER IPS (FAILED LOGONS ONLY — 4625)
# =============================
$attackers = $failedEvents |
    Where-Object { $_.IP -and $_.IP -ne "-" } |
    Group-Object IP |
    Sort-Object Count -Descending

$attackers | Format-Table Name, Count | Out-File "$OutputFolder\attacker_ips.txt"

Write-Host "DONE! Logs saved in $OutputFolder"
