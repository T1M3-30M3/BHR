# ============================================================
#  MODULE 12 - AUDIT & EVIDENCE TAMPERING
#  Bank/SOC: Log clearing, policy changes, time manipulation
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\12_Audit_Tampering.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"AUDIT TAMPERING ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "!!CRITICAL!! AUDIT LOG CLEARED (1102)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=1102} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ClearedBy=$x.Event.UserData.LogFileCleared.SubjectUserName;Domain=$x.Event.UserData.LogFileCleared.SubjectDomainName;LogonID=$x.Event.UserData.LogFileCleared.SubjectLogonId} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "AUDIT POLICY CHANGES (4719)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4719} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ChangedBy=$x.Event.EventData.Data[1].'#text';SubcategoryGUID=$x.Event.EventData.Data[7].'#text';Changes=$x.Event.EventData.Data[10].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SYSTEM TIME CHANGED (4616)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4616} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ChangedBy=$x.Event.EventData.Data[1].'#text';OldTime=$x.Event.EventData.Data[4].'#text';NewTime=$x.Event.EventData.Data[5].'#text';Process=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "EVENT LOG SERVICE STOPPED UNEXPECTEDLY (6006)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=6006} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENT EVENT LOG SIZES & RECORD COUNTS"
Get-WinEvent -ListLog Security,System,Application -EA SilentlyContinue |
    Select-Object LogName,RecordCount,FileSize,MaximumSizeInBytes,LastWriteTime |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENT AUDIT POLICY SETTINGS"
auditpol /get /category:* 2>$null | Out-File $Out -Append

Write-Section "DEFENDER REAL-TIME PROTECTION CHANGES (5001)"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=5001} -EA SilentlyContinue |
    Select-Object TimeCreated,Message | Format-List | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
