# ============================================================
#  MODULE 10 - REGISTRY CHANGES
#  Bank/SOC: Persistence via registry, config tampering
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\10_Registry_Changes.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"REGISTRY CHANGE ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "REGISTRY VALUE MODIFICATIONS (4657)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4657} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';KeyPath=$x.Event.EventData.Data[6].'#text';ValueName=$x.Event.EventData.Data[7].'#text';OldType=$x.Event.EventData.Data[8].'#text';NewType=$x.Event.EventData.Data[9].'#text';NewValue=$x.Event.EventData.Data[10].'#text'} } |
    Format-List | Out-File $Out -Append

Write-Section "RUN KEYS - HKLM (ALL USERS STARTUP)"
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -EA SilentlyContinue | Format-List | Out-File $Out -Append

Write-Section "RUN KEYS - HKCU (CURRENT USER STARTUP)"
Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -EA SilentlyContinue | Format-List | Out-File $Out -Append

Write-Section "RUNONCE KEYS - HKLM"
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" -EA SilentlyContinue | Format-List | Out-File $Out -Append

Write-Section "RUNONCE KEYS - HKCU"
Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" -EA SilentlyContinue | Format-List | Out-File $Out -Append

Write-Section "WINLOGON - USERINIT / SHELL (HIJACK CHECK)"
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -EA SilentlyContinue |
    Select-Object Userinit,Shell | Format-List | Out-File $Out -Append

Write-Section "IMAGE FILE EXECUTION OPTIONS (DEBUGGER HIJACKING)"
Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" -EA SilentlyContinue |
    Where-Object {(Get-ItemProperty $_.PSPath -EA SilentlyContinue).Debugger -ne $null} |
    ForEach-Object { [PSCustomObject]@{App=$_.PSChildName;Debugger=(Get-ItemProperty $_.PSPath).Debugger} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LSA SECURITY PACKAGES (DLL INJECTION PATH)"
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -EA SilentlyContinue |
    Select-Object 'Security Packages','Authentication Packages','Notification Packages' | Format-List | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
