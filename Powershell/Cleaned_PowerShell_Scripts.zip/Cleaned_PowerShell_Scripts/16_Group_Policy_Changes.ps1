# ============================================================
#  MODULE 16 - GROUP POLICY CHANGES
#  Bank/SOC: Rogue GPOs, policy disabling, domain-wide tampering
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\16_Group_Policy_Changes.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"GROUP POLICY ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "DOMAIN POLICY CHANGED (4739)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4739} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message}} | Format-List | Out-File $Out -Append

Write-Section "GPO MODIFIED (5136)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5136} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[3].'#text';ObjectDN=$x.Event.EventData.Data[8].'#text';Attribute=$x.Event.EventData.Data[10].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "GPO CREATED (5137)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5137} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[3].'#text';ObjectDN=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "GPO DELETED (5141)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5141} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[3].'#text';ObjectDN=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LOCAL SECURITY GROUP CHANGES (4735)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4735} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Group=$x.Event.EventData.Data[0].'#text';ChangedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "APPLIED GROUP POLICY RESULT (RSOP)"
gpresult /r 2>$null | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
