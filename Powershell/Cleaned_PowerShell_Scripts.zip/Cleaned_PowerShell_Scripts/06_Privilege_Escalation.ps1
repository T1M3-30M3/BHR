# ============================================================
#  MODULE 06 - PRIVILEGE ESCALATION
#  Bank/SOC: Admin abuse, token manipulation, UAC bypass
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\06_Privilege_Escalation.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"PRIVILEGE ESCALATION ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "SPECIAL PRIVILEGES ASSIGNED (4672) - ALL TIME"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4672} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';Domain=$x.Event.EventData.Data[2].'#text';LogonID=$x.Event.EventData.Data[3].'#text';Privileges=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "TOP USERS WITH SPECIAL PRIVILEGE LOGONS"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4672} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[1].'#text' } |
    Group-Object | Sort-Object Count -Descending | Select-Object -First 20 Count,Name |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "OBJECT PERMISSION CHANGES (4670)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4670} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';Object=$x.Event.EventData.Data[6].'#text';OldPermissions=$x.Event.EventData.Data[11].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "USER ACCOUNT CHANGES (4738) - PRIVILEGE MODIFICATION"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4738} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TargetUser=$x.Event.EventData.Data[0].'#text';ChangedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENT USER PRIVILEGES (WHOAMI)"
whoami /priv 2>$null | Out-File $Out -Append

Write-Section "CURRENT USER GROUPS"
whoami /groups 2>$null | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
