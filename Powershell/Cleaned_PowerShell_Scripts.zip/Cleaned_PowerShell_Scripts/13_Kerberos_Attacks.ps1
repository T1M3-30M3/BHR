# ============================================================
#  MODULE 13 - KERBEROS & DOMAIN ATTACKS
#  Bank/SOC: AS-REP Roasting, Kerberoasting, Golden/Silver Ticket
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\13_Kerberos_Attacks.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"KERBEROS ATTACK ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "KERBEROS TGT REQUESTS (4768)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4768} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';IP=$x.Event.EventData.Data[9].'#text';ResultCode=$x.Event.EventData.Data[5].'#text';TicketEncType=$x.Event.EventData.Data[6].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "KERBEROS PRE-AUTH FAILURES (4771) - AS-REP ROASTING"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4771} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';IP=$x.Event.EventData.Data[6].'#text';FailureCode=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "TOP USERS WITH KERBEROS FAILURES"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4771} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[0].'#text' } |
    Group-Object | Sort-Object Count -Descending | Select-Object -First 20 Count,Name |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "KERBEROS TGT REQUEST FAILURES (4772)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4772} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';FailureCode=$x.Event.EventData.Data[5].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SERVICE TICKET REQUESTS (4769) - KERBEROASTING INDICATOR"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4769} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';Service=$x.Event.EventData.Data[2].'#text';IP=$x.Event.EventData.Data[6].'#text';TicketEncType=$x.Event.EventData.Data[5].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "KERBEROASTING - RC4 ENCRYPTED TICKETS (EncType 0x17)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4769} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); $enc=$x.Event.EventData.Data[5].'#text'; if($enc -eq '0x17'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';Service=$x.Event.EventData.Data[2].'#text';IP=$x.Event.EventData.Data[6].'#text'}} } |
    Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
