# ============================================================
#  MODULE 18 - LIVE NETWORK CONNECTIONS
#  Bank/SOC: C2 beaconing, exfil channels, recon activity
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\18_Live_Network_Connections.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"LIVE NETWORK CONNECTION ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL ESTABLISHED CONNECTIONS - PROCESS + PATH"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{LocalPort=$_.LocalPort;RemoteIP=$_.RemoteAddress;RemotePort=$_.RemotePort;PID=$_.OwningProcess;Process=$p.Name;Path=$p.Path} } |
    Sort-Object RemoteIP | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LISTENING PORTS - PROCESS + PATH"
Get-NetTCPConnection -State Listen -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{Port=$_.LocalPort;PID=$_.OwningProcess;Process=$p.Name;Path=$p.Path} } |
    Sort-Object Port | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "TIME-WAIT CONNECTIONS (C2 BEACONING INDICATOR)"
Get-NetTCPConnection -State TimeWait -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{LocalPort=$_.LocalPort;RemoteIP=$_.RemoteAddress;RemotePort=$_.RemotePort;Process=$p.Name} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "UNIQUE REMOTE IPs CONNECTED"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    Select-Object -ExpandProperty RemoteAddress | Where-Object {$_ -ne '::' -and $_ -notmatch '^(127|169|0)\.'} |
    Sort-Object -Unique | Out-File $Out -Append

Write-Section "UNUSUAL PORTS (NOT 80/443/3389/445/135/53)"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    Where-Object {$_.RemotePort -notin @(80,443,3389,445,135,53,139,636,389,88)} |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{RemoteIP=$_.RemoteAddress;RemotePort=$_.RemotePort;Process=$p.Name;Path=$p.Path} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "DNS CACHE - RECENTLY RESOLVED"
Get-DnsClientCache -EA SilentlyContinue | Select-Object Entry,RecordName,RecordType,Data,TimeToLive | Sort-Object Entry | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ARP TABLE (LOCAL NETWORK HOSTS)"
arp -a 2>$null | Out-File $Out -Append

Write-Section "NETWORK ADAPTER CONFIGURATION"
Get-NetIPConfiguration -EA SilentlyContinue | Select-Object InterfaceAlias,IPv4Address,IPv6Address,DNSServer | Format-List | Out-File $Out -Append

Write-Section "ROUTING TABLE"
Get-NetRoute -EA SilentlyContinue | Where-Object {$_.RouteMetric -lt 9999} | Select-Object DestinationPrefix,NextHop,RouteMetric,InterfaceAlias | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
