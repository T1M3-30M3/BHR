# ============================================================
#  BANK / SOC EVENT LOG ANALYSIS - MASTER RUNNER
#  Runs all modules and saves each result to a separate .txt
#  Run as Administrator
# ============================================================

$OutputDir = "C:\SOC_Reports\$(Get-Date -Format 'yyyy-MM-dd_HH-mm')"
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
Write-Host "[*] Output directory: $OutputDir" -ForegroundColor Cyan

$scripts = @(
    "01_Failed_Logons.ps1",
    "02_Successful_Logons.ps1",
    "03_RDP_Sessions.ps1",
    "04_Lateral_Movement.ps1",
    "05_Account_Management.ps1",
    "06_Privilege_Escalation.ps1",
    "07_Scheduled_Tasks.ps1",
    "08_Service_Installation.ps1",
    "09_Process_Activity.ps1",
    "10_Registry_Changes.ps1",
    "11_Network_Share_Access.ps1",
    "12_Audit_Tampering.ps1",
    "13_Kerberos_Attacks.ps1",
    "14_Defender_Antivirus.ps1",
    "15_System_Events.ps1",
    "16_Group_Policy_Changes.ps1",
    "17_Persistence_Checks.ps1",
    "18_Live_Network_Connections.ps1",
    "19_Suspicious_Processes.ps1",
    "20_Bank_HighRisk_Summary.ps1"
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

foreach ($script in $scripts) {
    $path = Join-Path $ScriptDir $script
    if (Test-Path $path) {
        Write-Host "[+] Running $script ..." -ForegroundColor Green
        try {
            & $path -OutputDir $OutputDir
        } catch {
            Write-Host "[!] Error in $script : $_" -ForegroundColor Red
        }
    } else {
        Write-Host "[-] Not found: $script" -ForegroundColor Yellow
    }
}

Write-Host "`n[*] All done. Reports saved to: $OutputDir" -ForegroundColor Cyan
Invoke-Item $OutputDir
