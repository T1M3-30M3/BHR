# ============================================================
#  MODULE 19 - SUSPICIOUS PROCESS ANALYSIS
#  Bank/SOC: Hollow injection, masquerading, LOLBins, RATs
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\19_Suspicious_Processes.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"SUSPICIOUS PROCESS ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL RUNNING PROCESSES - FULL INVENTORY"
Get-Process | Select-Object Name,Id,CPU,WorkingSet,Path,@{N='Owner';E={(Get-WmiObject Win32_Process -Filter "ProcessId=$($_.Id)" -EA SilentlyContinue).GetOwner().User}} |
    Sort-Object CPU -Descending | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PROCESSES WITH NO FILE PATH (INJECTION / PROCESS HOLLOWING)"
Get-Process | Where-Object {$_.Path -eq $null -and $_.Name -notin @('Idle','System','Registry','Memory Compression','Secure System')} |
    Select-Object Name,Id,CPU,WorkingSet | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PROCESSES FROM TEMP / APPDATA (MALWARE STAGING)"
Get-Process | Where-Object {$_.Path -like "*\Temp\*" -or $_.Path -like "*\AppData\*" -or $_.Path -like "*\Downloads\*"} |
    Select-Object Name,Id,Path | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PROCESS MASQUERADING (svchost NOT from System32)"
Get-Process | Where-Object {$_.Name -eq 'svchost' -and $_.Path -ne 'C:\Windows\System32\svchost.exe'} |
    Select-Object Name,Id,Path | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LOLBIN PROCESSES RUNNING NOW"
$lolbins = @('certutil','mshta','wscript','cscript','regsvr32','rundll32','msiexec','installutil','regasm','regsvcs','odbcconf','xwizard','appsyncpublishing','syncappvpublishingserver','pcalua','cmstp','compiler')
Get-Process | Where-Object {$_.Name -in $lolbins} |
    Select-Object Name,Id,Path,CPU | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PROCESSES WITH NETWORK CONNECTIONS"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{Process=$p.Name;PID=$_.OwningProcess;RemoteIP=$_.RemoteAddress;RemotePort=$_.RemotePort;Path=$p.Path} } |
    Where-Object {$_} | Sort-Object Process | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CHILD PROCESSES OF OFFICE APPS (MACRO EXEC)"
$officeProcs = @('winword','excel','powerpnt','outlook','onenote')
Get-WmiObject Win32_Process -EA SilentlyContinue |
    Where-Object { $parent = Get-WmiObject Win32_Process -Filter "ProcessId=$($_.ParentProcessId)" -EA SilentlyContinue; $officeProcs -contains $parent.Name.Replace('.exe','').ToLower() } |
    Select-Object Name,ProcessId,CommandLine | Format-List | Out-File $Out -Append

Write-Section "HIGH CPU PROCESSES (TOP 10)"
Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 Name,Id,CPU,WorkingSet,Path | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
