# ============================================================
#  MODULE 17 - PERSISTENCE MECHANISMS (FULL SWEEP)
#  Bank/SOC: All common persistence locations in one report
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\17_Persistence_Checks.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"PERSISTENCE MECHANISM ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "REGISTRY RUN KEYS (ALL HIVES)"
@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run') |
    ForEach-Object { $p=$_; "`n[$p]" | Out-File $Out -Append; Get-ItemProperty $p -EA SilentlyContinue | Select-Object * -ExcludeProperty PS* | Format-List | Out-File $Out -Append }

Write-Section "STARTUP FOLDERS"
@("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup","$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup") |
    ForEach-Object { "`n[$_]" | Out-File $Out -Append; Get-ChildItem $_ -EA SilentlyContinue | Select-Object Name,FullName,CreationTime,LastWriteTime | Format-Table | Out-File $Out -Append }

Write-Section "WINLOGON HIJACK CHECK"
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -EA SilentlyContinue | Select-Object Shell,Userinit,UIHost | Format-List | Out-File $Out -Append

Write-Section "IMAGE FILE EXECUTION OPTIONS (DEBUGGER HIJACK)"
Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" -EA SilentlyContinue |
    ForEach-Object { $d=(Get-ItemProperty $_.PSPath -EA SilentlyContinue).Debugger; if($d){[PSCustomObject]@{App=$_.PSChildName;Debugger=$d}} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "COM OBJECT HIJACKING CANDIDATES (HKCU CLASSES)"
Get-ChildItem "HKCU:\Software\Classes\CLSID" -EA SilentlyContinue |
    Select-Object Name,PSChildName | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "BROWSER EXTENSIONS (CHROME - CURRENT USER)"
$chromePref = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Preferences"
if(Test-Path $chromePref){ (Get-Content $chromePref -Raw | ConvertFrom-Json -EA SilentlyContinue).extensions.settings.PSObject.Properties | Select-Object Name | Format-Table | Out-File $Out -Append } else { "Chrome preferences not found." | Out-File $Out -Append }

Write-Section "AUTORUN PROGRAMS (WMI)"
Get-CimInstance Win32_StartupCommand -EA SilentlyContinue |
    Select-Object Name,Command,Location,User | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SCHEDULED TASKS - NON-SYSTEM (PERSISTENCE RISK)"
Get-ScheduledTask -EA SilentlyContinue |
    Where-Object {$_.Actions.Execute -notlike '*System32*' -and $_.Actions.Execute -notlike '*SysWOW64*' -and $_.Actions.Execute -ne $null -and $_.State -ne 'Disabled'} |
    Select-Object TaskName,TaskPath,State,@{N='Execute';E={$_.Actions.Execute}},@{N='Args';E={$_.Actions.Arguments}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "INSTALLED SERVICES - NON-STANDARD PATH"
Get-WmiObject Win32_Service -EA SilentlyContinue |
    Where-Object {$_.PathName -notlike '*System32*' -and $_.PathName -notlike '*Program Files*' -and $_.PathName -notlike '*SysWOW64*' -and $_.PathName -ne $null -and $_.StartMode -eq 'Auto'} |
    Select-Object Name,PathName,StartName,State | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
