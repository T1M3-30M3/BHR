# ============================================================
#  MODULE 03 - RDP SESSION TRACKING
#  Bank/SOC: Unauthorized remote access, session hijacking
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\03_RDP_Sessions.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"RDP SESSION ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "RDP SUCCESSFUL CONNECTIONS (4624 Type 10)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); if($x.Event.EventData.Data[8].'#text' -eq '10'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';IP=$x.Event.EventData.Data[18].'#text'}} } |
    Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "RDP SESSION RECONNECTED (4778)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4778} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';ClientIP=$x.Event.EventData.Data[2].'#text';SessionName=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "RDP SESSION DISCONNECTED (4779)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4779} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';ClientIP=$x.Event.EventData.Data[2].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "WORKSTATION LOCKED / UNLOCKED (4800/4801)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4800,4801} -EA SilentlyContinue |
    Select-Object TimeCreated,Id,@{N='User';E={$_.Properties[1].Value}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "RDP FAILED ATTEMPTS (4625 Type 10)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4625} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); if($x.Event.EventData.Data[10].'#text' -eq '10'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';IP=$x.Event.EventData.Data[19].'#text'}} } |
    Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "RDP BRUTE-FORCE - TOP SOURCE IPs"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4625} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); if($x.Event.EventData.Data[10].'#text' -eq '10'){$x.Event.EventData.Data[19].'#text'} } |
    Where-Object {$_} | Group-Object | Sort-Object Count -Descending | Select-Object -First 15 Count,Name |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
