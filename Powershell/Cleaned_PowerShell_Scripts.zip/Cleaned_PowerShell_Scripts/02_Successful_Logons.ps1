# ============================================================
#  MODULE 02 - SUCCESSFUL LOGONS (4624)
#  Bank/SOC: Baseline deviation, off-hours access, new IPs
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\02_Successful_Logons.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"SUCCESSFUL LOGON ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL SUCCESSFUL LOGONS - FULL DETAIL"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object {
        $x = [xml]$_.ToXml()
        [PSCustomObject]@{
            Time       = $_.TimeCreated
            User       = $x.Event.EventData.Data[5].'#text'
            Domain     = $x.Event.EventData.Data[6].'#text'
            LogonType  = $x.Event.EventData.Data[8].'#text'
            IP         = $x.Event.EventData.Data[18].'#text'
            Workstation= $x.Event.EventData.Data[11].'#text'
            AuthPkg    = $x.Event.EventData.Data[14].'#text'
        }
    } | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LOGONS BY USER - FREQUENCY"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[5].'#text' } |
    Group-Object | Sort-Object Count -Descending | Select-Object -First 30 Count,Name |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "RDP LOGONS (Type 10)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml(); $t=$x.Event.EventData.Data[8].'#text'
        if($t -eq '10'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';IP=$x.Event.EventData.Data[18].'#text'}}
    } | Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NETWORK LOGONS (Type 3) - LATERAL MOVEMENT RISK"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml(); $t=$x.Event.EventData.Data[8].'#text'
        if($t -eq '3'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';IP=$x.Event.EventData.Data[18].'#text'}}
    } | Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "AFTER-HOURS SUCCESSFUL LOGONS - BANK HIGH ALERT"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    Where-Object { $_.TimeCreated.Hour -lt 7 -or $_.TimeCreated.Hour -gt 19 } |
    ForEach-Object {
        $x=[xml]$_.ToXml()
        [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';Type=$x.Event.EventData.Data[8].'#text';IP=$x.Event.EventData.Data[18].'#text'}
    } | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CLEARTEXT / NTLM LOGONS (Type 8) - CREDENTIAL RISK"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml(); $t=$x.Event.EventData.Data[8].'#text'
        if($t -eq '8'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';IP=$x.Event.EventData.Data[18].'#text'}}
    } | Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
