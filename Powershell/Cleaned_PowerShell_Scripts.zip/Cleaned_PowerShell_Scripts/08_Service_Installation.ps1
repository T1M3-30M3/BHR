# ============================================================
#  MODULE 08 - SERVICE INSTALLATION
#  Bank/SOC: Malware as service, rootkits, backdoors
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\08_Service_Installation.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"SERVICE INSTALLATION ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL NEW SERVICES INSTALLED (7045)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=7045} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ServiceName=$x.Event.EventData.Data[0].'#text';ImagePath=$x.Event.EventData.Data[1].'#text';ServiceType=$x.Event.EventData.Data[2].'#text';StartType=$x.Event.EventData.Data[3].'#text';RunAs=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NEW SERVICES VIA API (4697)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4697} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ServiceName=$x.Event.EventData.Data[4].'#text';ServiceFile=$x.Event.EventData.Data[5].'#text';ServiceType=$x.Event.EventData.Data[6].'#text';StartType=$x.Event.EventData.Data[7].'#text';InstalledBy=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SERVICE STARTUP TYPE CHANGES (7040)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=7040} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ALL AUTO-START SERVICES - CURRENT"
Get-Service | Where-Object {$_.StartType -eq 'Automatic'} |
    Select-Object Name,DisplayName,Status,@{N='Path';E={(Get-WmiObject Win32_Service -Filter "Name='$($_.Name)'" -EA SilentlyContinue).PathName}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SERVICES RUNNING AS SYSTEM"
Get-WmiObject Win32_Service -EA SilentlyContinue |
    Where-Object {$_.StartName -eq 'LocalSystem' -and $_.State -eq 'Running'} |
    Select-Object Name,DisplayName,PathName,StartMode | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SUSPICIOUS SERVICE PATHS (Not in System32/Program Files)"
Get-WmiObject Win32_Service -EA SilentlyContinue |
    Where-Object {$_.PathName -notlike '*System32*' -and $_.PathName -notlike '*Program Files*' -and $_.PathName -notlike '*SysWOW64*' -and $_.PathName -ne $null} |
    Select-Object Name,DisplayName,PathName,StartName,State | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
