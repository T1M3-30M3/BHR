# ============================================================
#  MODULE 15 - SYSTEM EVENTS
#  Bank/SOC: Reboots, uptime anomalies, OS events
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\15_System_Events.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"SYSTEM EVENTS ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL SYSTEM SHUTDOWNS / RESTARTS (1074)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=1074} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Process=$x.Event.EventData.Data[0].'#text';Reason=$x.Event.EventData.Data[2].'#text';User=$x.Event.EventData.Data[6].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SYSTEM BOOT EVENTS (6005)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=6005} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "EVENT LOG STOPPED (6006)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=6006} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "DAILY UPTIME RECORDS (6013)"
Get-WinEvent -FilterHashtable @{LogName='System';Id=6013} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;UptimeSeconds=$x.Event.EventData.Data[0].'#text';UptimeDays=[math]::Round([int]$x.Event.EventData.Data[0].'#text'/86400,1)} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "WINDOWS STARTUP EVENTS (4608)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4608} -EA SilentlyContinue |
    Select-Object TimeCreated,Message | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENT SYSTEM UPTIME"
$boot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
$uptime = (Get-Date) - $boot
"Last Boot:   $boot" | Out-File $Out -Append
"Uptime:      $($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m" | Out-File $Out -Append

Write-Section "SYSTEM INFORMATION"
Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture,RegisteredUser,SerialNumber,InstallDate | Format-List | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
