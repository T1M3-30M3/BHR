# ============================================================
#  MODULE 05 - ACCOUNT MANAGEMENT
#  Bank/SOC: Rogue accounts, privilege creep, insider threats
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\05_Account_Management.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"ACCOUNT MANAGEMENT ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ACCOUNTS CREATED (4720)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4720} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;NewUser=$x.Event.EventData.Data[0].'#text';NewUserSID=$x.Event.EventData.Data[2].'#text';CreatedBy=$x.Event.EventData.Data[4].'#text';Domain=$x.Event.EventData.Data[5].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNTS DELETED (4726)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4726} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;DeletedUser=$x.Event.EventData.Data[0].'#text';DeletedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNTS ENABLED (4722)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4722} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Account=$x.Event.EventData.Data[0].'#text';EnabledBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNTS DISABLED (4725)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4725} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Account=$x.Event.EventData.Data[0].'#text';DisabledBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNTS LOCKED OUT (4740)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4740} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;LockedUser=$x.Event.EventData.Data[0].'#text';CallerPC=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNTS UNLOCKED (4767)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4767} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;UnlockedUser=$x.Event.EventData.Data[0].'#text';UnlockedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PASSWORD RESETS (4724) - PRIVILEGED USER CHANGED ANOTHER"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4724} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TargetUser=$x.Event.EventData.Data[0].'#text';ResetBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ADDED TO SECURITY GROUPS (4732) - PRIVILEGE ESCALATION"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4732} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;AddedUser=$x.Event.EventData.Data[0].'#text';Group=$x.Event.EventData.Data[2].'#text';AddedBy=$x.Event.EventData.Data[6].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "REMOVED FROM SECURITY GROUPS (4733)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4733} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;RemovedUser=$x.Event.EventData.Data[0].'#text';Group=$x.Event.EventData.Data[2].'#text';RemovedBy=$x.Event.EventData.Data[6].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACCOUNT NAME CHANGES (4781) - IDENTITY MASKING"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4781} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;OldName=$x.Event.EventData.Data[0].'#text';NewName=$x.Event.EventData.Data[1].'#text';ChangedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ALL LOCAL USERS - CURRENT STATE"
Get-LocalUser | Select-Object Name,Enabled,LastLogon,PasswordLastSet,PasswordExpires,Description |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LOCAL ADMINISTRATORS"
Get-LocalGroupMember -Group "Administrators" -EA SilentlyContinue |
    Select-Object Name,ObjectClass,PrincipalSource | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
