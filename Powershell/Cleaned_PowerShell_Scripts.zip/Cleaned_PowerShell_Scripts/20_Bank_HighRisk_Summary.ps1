# ============================================================
#  MODULE 20 - BANK HIGH-RISK SUMMARY REPORT
#  Aggregates the most critical indicators across all modules
#  into one executive-level incident summary file
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\20_BANK_HIGHRISK_SUMMARY.txt"
$Sep = "=" * 70
$Alert = "!!! ALERT !!!"

function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
function Write-Alert($t)   { "`n*** $Alert - $t ***" | Out-File $Out -Append }

@"
$Sep
  BANK / SOC HIGH-RISK INCIDENT SUMMARY REPORT
  Generated: $(Get-Date)
  Hostname:  $env:COMPUTERNAME
  Domain:    $env:USERDOMAIN
  User:      $env:USERNAME
$Sep
"@ | Out-File $Out

# --- 1. Audit Log Cleared
Write-Section "1. AUDIT LOG CLEARED (1102) - EVIDENCE DESTRUCTION"
$cleared = Get-WinEvent -FilterHashtable @{LogName='Security';Id=1102} -EA SilentlyContinue
if($cleared){ Write-Alert "Audit log was cleared $($cleared.Count) time(s)!"; $cleared | Select-Object TimeCreated,Message | Format-Table | Out-File $Out -Append }
else { "[OK] No audit log clearing detected." | Out-File $Out -Append }

# --- 2. After-hours logons
Write-Section "2. AFTER-HOURS SUCCESSFUL LOGONS (Before 07:00 / After 20:00)"
$afterHours = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    Where-Object { $_.TimeCreated.Hour -lt 7 -or $_.TimeCreated.Hour -gt 20 } |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';Type=$x.Event.EventData.Data[8].'#text';IP=$x.Event.EventData.Data[18].'#text'} }
if($afterHours){ Write-Alert "$($afterHours.Count) after-hours logon(s) detected!"; $afterHours | Format-Table | Out-File $Out -Append }
else { "[OK] No after-hours logons detected." | Out-File $Out -Append }

# --- 3. Brute-force check
Write-Section "3. BRUTE-FORCE INDICATORS (Top Failed Logon Accounts)"
$topFailed = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4625} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[5].'#text' } |
    Group-Object | Sort-Object Count -Descending | Select-Object -First 10
$totalFails = ($topFailed | Measure-Object Count -Sum).Sum
if($totalFails -gt 50){ Write-Alert "HIGH volume of failed logons: $totalFails total!" }
$topFailed | Format-Table | Out-File $Out -Append

# --- 4. New admin accounts
Write-Section "4. NEW USER ACCOUNTS CREATED (4720)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4720} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;NewUser=$x.Event.EventData.Data[0].'#text';CreatedBy=$x.Event.EventData.Data[4].'#text'} } |
    Format-Table | Out-File $Out -Append

# --- 5. Privilege escalation
Write-Section "5. USERS ADDED TO PRIVILEGED GROUPS (4732)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4732} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';Group=$x.Event.EventData.Data[2].'#text';By=$x.Event.EventData.Data[6].'#text'} } |
    Format-Table | Out-File $Out -Append

# --- 6. New services
Write-Section "6. NEW SERVICES INSTALLED (7045) - MALWARE RISK"
$newSvcs = Get-WinEvent -FilterHashtable @{LogName='System';Id=7045} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Name=$x.Event.EventData.Data[0].'#text';Path=$x.Event.EventData.Data[1].'#text'} }
if($newSvcs){ Write-Alert "$($newSvcs.Count) new service(s) installed!"; $newSvcs | Format-Table | Out-File $Out -Append }
else { "[OK] No new services detected." | Out-File $Out -Append }

# --- 7. Scheduled tasks
Write-Section "7. SCHEDULED TASKS CREATED (4698)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4698} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;Task=$x.Event.EventData.Data[0].'#text';By=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table | Out-File $Out -Append

# --- 8. Malware detections
Write-Section "8. DEFENDER MALWARE DETECTIONS"
$threats = Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1116} -EA SilentlyContinue
if($threats){ Write-Alert "$($threats.Count) malware detection(s)!"; $threats | Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} | Format-Table | Out-File $Out -Append }
else { "[OK] No malware detections." | Out-File $Out -Append }

# --- 9. Kerberoasting
Write-Section "9. KERBEROASTING - RC4 TICKETS (4769 EncType 0x17)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4769} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); if($x.Event.EventData.Data[5].'#text' -eq '0x17'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[0].'#text';Service=$x.Event.EventData.Data[2].'#text'}} } |
    Where-Object {$_} | Format-Table | Out-File $Out -Append

# --- 10. Process injection
Write-Section "10. PROCESSES WITH NO PATH (INJECTION INDICATOR)"
Get-Process | Where-Object {$_.Path -eq $null -and $_.Name -notin @('Idle','System','Registry','Memory Compression','Secure System')} |
    Select-Object Name,Id | Format-Table | Out-File $Out -Append

# --- 11. C2 / unusual connections
Write-Section "11. UNUSUAL OUTBOUND CONNECTIONS (Non-standard ports)"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    Where-Object {$_.RemotePort -notin @(80,443,3389,445,135,53,139,636,389,88) -and $_.RemoteAddress -notmatch '^(127|169|0|10|192\.168|172)\.'} |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{RemoteIP=$_.RemoteAddress;Port=$_.RemotePort;Process=$p.Name;Path=$p.Path} } |
    Format-Table | Out-File $Out -Append

# --- 12. Local admins
Write-Section "12. CURRENT LOCAL ADMINISTRATORS"
Get-LocalGroupMember -Group "Administrators" -EA SilentlyContinue |
    Select-Object Name,ObjectClass,PrincipalSource | Format-Table | Out-File $Out -Append

# --- Final stamp
"`n$Sep" | Out-File $Out -Append
"REPORT COMPLETE - $(Get-Date)" | Out-File $Out -Append
"Saved to: $Out" | Out-File $Out -Append
$Sep | Out-File $Out -Append

Write-Host "[+] HIGH-RISK SUMMARY saved: $Out" -ForegroundColor Yellow
Write-Host "[*] REVIEW THIS FILE FIRST FOR TRIAGE." -ForegroundColor Cyan
