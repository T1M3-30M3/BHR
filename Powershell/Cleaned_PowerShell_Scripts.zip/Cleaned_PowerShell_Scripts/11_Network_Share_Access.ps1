# ============================================================
#  MODULE 11 - NETWORK & SHARE ACCESS
#  Bank/SOC: Data exfiltration, recon, unauthorized file access
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\11_Network_Share_Access.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"NETWORK & SHARE ACCESS ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "NETWORK SHARE ACCESS (5140)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5140} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';IP=$x.Event.EventData.Data[5].'#text';ShareName=$x.Event.EventData.Data[7].'#text';SharePath=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NEW SHARES CREATED (5142) - EXFIL RISK"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5142} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';ShareName=$x.Event.EventData.Data[7].'#text';SharePath=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SHARE ACCESS BLOCKED BY WFP (5157)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5157} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;ProcessID=$x.Event.EventData.Data[0].'#text';Direction=$x.Event.EventData.Data[3].'#text';SrcIP=$x.Event.EventData.Data[4].'#text';SrcPort=$x.Event.EventData.Data[5].'#text';DestIP=$x.Event.EventData.Data[6].'#text';DestPort=$x.Event.EventData.Data[7].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACTIVE TCP CONNECTIONS + PROCESS"
Get-NetTCPConnection -State Established -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{LocalPort=$_.LocalPort;RemoteIP=$_.RemoteAddress;RemotePort=$_.RemotePort;PID=$_.OwningProcess;Process=$p.Name;Path=$p.Path} } |
    Sort-Object RemoteIP | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "LISTENING PORTS + PROCESS + PATH"
Get-NetTCPConnection -State Listen -EA SilentlyContinue |
    ForEach-Object { $p=Get-Process -Id $_.OwningProcess -EA SilentlyContinue; [PSCustomObject]@{Port=$_.LocalPort;PID=$_.OwningProcess;Process=$p.Name;Path=$p.Path} } |
    Sort-Object Port | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "DNS CACHE - RECENTLY RESOLVED DOMAINS"
Get-DnsClientCache -EA SilentlyContinue |
    Select-Object Entry,RecordName,RecordType,Data,TimeToLive | Sort-Object Entry |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "ACTIVE SMB SESSIONS"
Get-SmbSession -EA SilentlyContinue |
    Select-Object ClientComputerName,ClientUserName,NumOpens,SecondsIdle,SecondsExist |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENT SMB SHARES"
Get-SmbShare -EA SilentlyContinue |
    Select-Object Name,Path,Description,ShareState | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
