# ============================================================
#  MODULE 07 - SCHEDULED TASKS
#  Bank/SOC: Persistence, malware scheduling, lateral exec
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\07_Scheduled_Tasks.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"SCHEDULED TASK ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL SCHEDULED TASKS CREATED (4698)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4698} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TaskName=$x.Event.EventData.Data[0].'#text';CreatedBy=$x.Event.EventData.Data[1].'#text';TaskContent=$x.Event.EventData.Data[4].'#text'} } |
    Format-List | Out-File $Out -Append

Write-Section "SCHEDULED TASKS ENABLED (4700)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4700} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TaskName=$x.Event.EventData.Data[0].'#text';EnabledBy=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SCHEDULED TASKS DISABLED (4701)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4701} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TaskName=$x.Event.EventData.Data[0].'#text';DisabledBy=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SCHEDULED TASKS MODIFIED (4702)"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4702} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;TaskName=$x.Event.EventData.Data[0].'#text';ModifiedBy=$x.Event.EventData.Data[1].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "CURRENTLY REGISTERED TASKS - ALL (LIVE)"
Get-ScheduledTask | Select-Object TaskName,TaskPath,State,@{N='Execute';E={$_.Actions.Execute}},@{N='Args';E={$_.Actions.Arguments}} |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SUSPICIOUS TASKS (NON-SYSTEM PATH)"
Get-ScheduledTask | Where-Object {$_.Actions.Execute -notlike '*System32*' -and $_.Actions.Execute -notlike '*SysWOW64*' -and $_.Actions.Execute -ne $null} |
    Select-Object TaskName,TaskPath,@{N='Execute';E={$_.Actions.Execute}},@{N='Args';E={$_.Actions.Arguments}},State |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "TASK LAST RUN TIMES"
Get-ScheduledTask | Get-ScheduledTaskInfo -EA SilentlyContinue |
    Select-Object TaskName,LastRunTime,NextRunTime,LastTaskResult | Sort-Object LastRunTime -Descending |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
