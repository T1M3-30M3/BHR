# ============================================================
#  MODULE 09 - PROCESS ACTIVITY
#  Bank/SOC: Malware execution, LOLBins, encoded commands
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\09_Process_Activity.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"PROCESS ACTIVITY ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "ALL PROCESSES CREATED (4688) - WITH COMMAND LINES"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4688} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';NewProcess=$x.Event.EventData.Data[5].'#text';CmdLine=$x.Event.EventData.Data[8].'#text';ParentProcess=$x.Event.EventData.Data[13].'#text';ParentCmdLine=$x.Event.EventData.Data[14].'#text'} } |
    Format-List | Out-File $Out -Append

Write-Section "SUSPICIOUS LOLBIN EXECUTION (certutil/mshta/wscript/cscript/regsvr32/rundll32)"
$lolbins = 'certutil','mshta','wscript','cscript','regsvr32','rundll32','msiexec','installutil','regasm','regsvcs'
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4688} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml(); $proc=$x.Event.EventData.Data[5].'#text'
        foreach($l in $lolbins){ if($proc -like "*$l*"){ [PSCustomObject]@{Time=$_.TimeCreated;Process=$proc;CmdLine=$x.Event.EventData.Data[8].'#text';User=$x.Event.EventData.Data[1].'#text'}; break } }
    } | Where-Object {$_} | Format-List | Out-File $Out -Append

Write-Section "BASE64 / ENCODED COMMANDS IN PROCESS LOGS"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4688} -EA SilentlyContinue |
    Where-Object {$_.Message -match '-[Ee]nc|-[Ee]ncodedCommand|[A-Za-z0-9+/]{100,}'} |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message}} | Format-List | Out-File $Out -Append

Write-Section "POWERSHELL EXECUTIONS"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4688} -EA SilentlyContinue |
    Where-Object {$_.Message -like '*powershell*'} |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;CmdLine=$x.Event.EventData.Data[8].'#text';User=$x.Event.EventData.Data[1].'#text'} } |
    Format-List | Out-File $Out -Append

Write-Section "CURRENTLY RUNNING PROCESSES - LIVE"
Get-Process | Select-Object Name,Id,CPU,WorkingSet,Path,@{N='Owner';E={(Get-WmiObject Win32_Process -Filter "ProcessId=$($_.Id)" -EA SilentlyContinue).GetOwner().User}} |
    Sort-Object CPU -Descending | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "PROCESSES WITH NO FILE PATH (INJECTION / HOLLOW INDICATOR)"
Get-Process | Where-Object {$_.Path -eq $null -and $_.Name -notin @('Idle','System','Registry','Memory Compression','Secure System')} |
    Select-Object Name,Id,CPU,WorkingSet | Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
