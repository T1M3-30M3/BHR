# ============================================================
#  MODULE 14 - DEFENDER / ANTIVIRUS
#  Bank/SOC: Malware detections, remediation failures, bypass
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\14_Defender_Antivirus.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"DEFENDER / ANTIVIRUS ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "MALWARE DETECTIONS (1116)"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1116} -EA SilentlyContinue |
    ForEach-Object { [PSCustomObject]@{Time=$_.TimeCreated;ThreatName=$_.Properties[7].Value;Severity=$_.Properties[8].Value;FilePath=$_.Properties[21].Value;User=$_.Properties[26].Value;ActionTaken=$_.Properties[10].Value} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "REMEDIATION STARTED (1118)"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1118} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "REMEDIATION SUCCEEDED (1119)"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1119} -EA SilentlyContinue |
    Select-Object TimeCreated,@{N='Msg';E={$_.Message.Split("`n")[0]}} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "!!ALERT!! REMEDIATION FAILED (1120)"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=1120} -EA SilentlyContinue |
    Select-Object TimeCreated,Message | Format-List | Out-File $Out -Append

Write-Section "REAL-TIME PROTECTION CHANGED (5001) - BYPASS ATTEMPT"
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Windows Defender/Operational';Id=5001} -EA SilentlyContinue |
    Select-Object TimeCreated,Message | Format-List | Out-File $Out -Append

Write-Section "DEFENDER CURRENT STATUS"
Get-MpComputerStatus -EA SilentlyContinue |
    Select-Object AMRunningMode,RealTimeProtectionEnabled,AntivirusEnabled,AntispywareEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,NISEnabled,OnAccessProtectionEnabled,AMEngineVersion,AntivirusSignatureVersion,AntivirusSignatureLastUpdated |
    Format-List | Out-File $Out -Append

Write-Section "DEFENDER THREAT DETECTION HISTORY"
Get-MpThreatDetection -EA SilentlyContinue |
    Select-Object ThreatID,ActionSuccess,DetectionSourceTypeID,DomainUser,ProcessName,Resources |
    Format-List | Out-File $Out -Append

Write-Section "ACTIVE THREATS"
Get-MpThreat -EA SilentlyContinue |
    Select-Object ThreatName,SeverityID,IsActive,Resources | Format-List | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
