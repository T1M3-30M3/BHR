# ============================================================
#  MODULE 04 - LATERAL MOVEMENT DETECTION
#  Bank/SOC: Pass-the-Hash, Pass-the-Ticket, net use, WMI
# ============================================================
param([string]$OutputDir = "C:\SOC_Reports")
$Out = "$OutputDir\04_Lateral_Movement.txt"
$Sep = "=" * 70
function Write-Section($t) { "`n$Sep`n  $t`n$Sep" | Out-File $Out -Append }
"LATERAL MOVEMENT ANALYSIS - $(Get-Date)" | Out-File $Out

Write-Section "EXPLICIT CREDENTIAL LOGONS (4648) - PASS-THE-HASH INDICATOR"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4648} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml()
        [PSCustomObject]@{Time=$_.TimeCreated;SubjectUser=$x.Event.EventData.Data[1].'#text';TargetUser=$x.Event.EventData.Data[5].'#text';TargetServer=$x.Event.EventData.Data[9].'#text';Process=$x.Event.EventData.Data[11].'#text'}
    } | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NETWORK LOGONS (4624 Type 3) - SMB / NET USE"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml(); $t=$x.Event.EventData.Data[8].'#text'
        if($t -eq '3'){[PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[5].'#text';Domain=$x.Event.EventData.Data[6].'#text';IP=$x.Event.EventData.Data[18].'#text';AuthPkg=$x.Event.EventData.Data[14].'#text'}}
    } | Where-Object {$_} | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NTLM AUTHENTICATION EVENTS (4776) - PASS-THE-HASH"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=4776} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml()
        [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';Workstation=$x.Event.EventData.Data[2].'#text';ErrorCode=$x.Event.EventData.Data[3].'#text'}
    } | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "NETWORK SHARE ACCESS (5140) - DATA STAGING"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5140} -EA SilentlyContinue |
    ForEach-Object {
        $x=[xml]$_.ToXml()
        [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';IP=$x.Event.EventData.Data[5].'#text';ShareName=$x.Event.EventData.Data[7].'#text'}
    } | Format-Table -AutoSize | Out-File $Out -Append

Write-Section "SHARE ACCESS FREQUENCY BY USER"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5140} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[1].'#text' } |
    Group-Object | Sort-Object Count -Descending | Select-Object -First 20 Count,Name |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Section "UNIQUE SHARES ACCESSED"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5140} -EA SilentlyContinue |
    ForEach-Object { ([xml]$_.ToXml()).Event.EventData.Data[7].'#text' } |
    Sort-Object -Unique | Out-File $Out -Append

Write-Section "NEW NETWORK SHARES CREATED (5142) - EXFIL RISK"
Get-WinEvent -FilterHashtable @{LogName='Security';Id=5142} -EA SilentlyContinue |
    ForEach-Object { $x=[xml]$_.ToXml(); [PSCustomObject]@{Time=$_.TimeCreated;User=$x.Event.EventData.Data[1].'#text';ShareName=$x.Event.EventData.Data[7].'#text';SharePath=$x.Event.EventData.Data[8].'#text'} } |
    Format-Table -AutoSize | Out-File $Out -Append

Write-Host "[+] Saved: $Out" -ForegroundColor Green
